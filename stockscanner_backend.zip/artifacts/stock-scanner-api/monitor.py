"""
Uptime monitor — completely standalone, zero impact on main.py or any tab.

Checks https://nclexai.org/stock-api/ every 30 minutes, 24/7.
Sends email to owner if the site is down for 2 consecutive checks,
and a recovery email when it comes back up.

Also checks the AIEM Telegram notifier's /api/health twice per weekday -
once after 9:35 AM ET (stock picks brief) and again after 10:35 AM ET
(call options picks brief), since 2026-07-01 those are two independent
sends at two different times, not one combined brief. A plain HTTP 200
from that service does not prove today's Telegram message actually sent
(e.g. Telegram API down, bad token, or the DB read failing) — so this
reads the JSON body's `today_status_stock.status` / `today_status_options
.status` fields (DB-backed, true across process instances - NOT
`last_run`, which is only in-memory for whichever instance happens to
answer the request) and emails the owner unless the relevant one contains
"=True" by its check time. This is the only failure-visibility channel
for that notifier, since it has no delivery channel of its own besides
Telegram.

Run with `--once` to execute both checks a single time and exit,
instead of the normal infinite loop - useful for manual verification.
Set AIEM_HEALTH_URL env var to override the health endpoint checked
(e.g. to point at a local dev instance instead of production).
"""
import os
import time
import json
import urllib.request
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
import pytz

OWNER_EMAIL       = os.getenv("ALERT_EMAIL", "joeldcarlo@gmail.com")
CHECK_URL         = "https://nclexai.org/stock-api/"
AIEM_HEALTH_URL   = os.getenv("AIEM_HEALTH_URL", "https://nclexai.org/aiem-telegram/api/health")
CHECK_TIMEOUT     = 15         # seconds per ping
SLEEP_TICK        = 60         # seconds between loop ticks
CHECK_INTERVAL    = 30 * 60   # 30 minutes between checks
ET = pytz.timezone("America/New_York")


def _smtp_send(subject: str, body: str):
    host = os.getenv("SMTP_HOST", "smtp.gmail.com")
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "")
    pwd  = os.getenv("SMTP_PASS", "")
    if not user or not pwd:
        print(f"[monitor] SMTP not configured — cannot send: {subject}")
        return
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = f"StockScanner AI Monitor <{user}>"
    msg["To"]      = OWNER_EMAIL
    msg.attach(MIMEText(body, "html"))
    try:
        with smtplib.SMTP(host, port, timeout=10) as s:
            s.starttls()
            s.login(user, pwd)
            s.sendmail(user, [OWNER_EMAIL], msg.as_string())
        print(f"[monitor] alert sent: {subject}")
    except Exception as e:
        print(f"[monitor] SMTP error: {e}")


def _ping() -> bool:
    try:
        req = urllib.request.Request(
            CHECK_URL, headers={"User-Agent": "StockScanner-Monitor/1.0"}
        )
        with urllib.request.urlopen(req, timeout=CHECK_TIMEOUT) as r:
            return r.status == 200
    except Exception:
        return False


def _check_aiem_notifier(brief_type: str):
    """Returns (ok, detail_str) for ONE brief_type ('stock' or 'options').
    ok=False covers 'unreachable', 'nothing recorded yet', and 'recorded but
    the send itself failed'.

    Reads `today_status_<brief_type>`, which the notifier populates from its
    own DB table (shared truth across process instances) — NOT `last_run`,
    which is only that specific process's in-memory state and would be
    stale/wrong if a *different* instance won the idempotency claim and
    actually sent (e.g. during a redeploy overlap)."""
    try:
        req = urllib.request.Request(
            AIEM_HEALTH_URL, headers={"User-Agent": "StockScanner-Monitor/1.0"}
        )
        with urllib.request.urlopen(req, timeout=CHECK_TIMEOUT) as r:
            body = json.loads(r.read())
    except Exception as e:
        return False, f"health endpoint unreachable: {e}"

    today_status = body.get(f"today_status_{brief_type}") or {}
    status = str(today_status.get("status", ""))
    # A real successful send looks like "sent_ok=True" or "sent_empty ok=True".
    # "sent_ok=False" / "sent_empty ok=False" / "in_progress" / "failed_*" /
    # "not_run_yet" / "log_lookup_error" must all be treated as failures.
    if "=True" in status:
        return True, status
    return False, status or "no status recorded for today"


def _send_aiem_failure_alert(brief_type: str, detail: str, when_str: str):
    label = "stock" if brief_type == "stock" else "call options"
    _smtp_send(
        f"🚨 AIEM Telegram independent {label} picks brief did not send",
        f"<p><strong>No confirmed {label} brief send as of {when_str}.</strong></p>"
        f"<p>Health check detail: {detail}</p>"
        f"<p>Checked: <a href='{AIEM_HEALTH_URL}'>{AIEM_HEALTH_URL}</a></p>"
        f"<p>You likely did NOT receive today's AIEM {label} picks on Telegram.</p>"
    )


def run():
    print(f"[monitor] started — checking {CHECK_URL} every 30 min, 24/7")
    consecutive_failures  = 0
    site_was_down              = False
    last_check_time            = 0.0
    aiem_stock_alert_sent_date   = None   # ET date string; reset daily to avoid re-alerting every 30 min
    aiem_options_alert_sent_date = None

    while True:
        now_ts = time.time()

        if (now_ts - last_check_time) >= CHECK_INTERVAL:
            last_check_time = now_ts
            up      = _ping()
            now_et  = datetime.now(ET)
            now_str = now_et.strftime("%a %b %d %I:%M %p ET")

            if up:
                print(f"[monitor] {now_str} — UP ✓")
                if site_was_down:
                    _smtp_send(
                        "✅ StockScanner AI is back online",
                        f"<p>Your site is back up as of <strong>{now_str}</strong>.</p>"
                        f"<p>URL: <a href='{CHECK_URL}'>{CHECK_URL}</a></p>"
                    )
                consecutive_failures = 0
                site_was_down        = False
            else:
                consecutive_failures += 1
                print(f"[monitor] {now_str} — DOWN ✗ (consecutive: {consecutive_failures})")
                if consecutive_failures >= 2 and not site_was_down:
                    site_was_down = True
                    _smtp_send(
                        "🚨 StockScanner AI is DOWN",
                        f"<p><strong>Site did not respond at {now_str}.</strong></p>"
                        f"<p>URL checked: <a href='{CHECK_URL}'>{CHECK_URL}</a></p>"
                        f"<p>2 consecutive failed checks (30-min interval). "
                        f"Subscribers may be affected.</p>"
                        f"<p>Fix: go to "
                        f"<a href='https://replit.com'>replit.com</a> → "
                        f"open this project → click <strong>Publish → Redeploy</strong>.</p>"
                    )

            # AIEM Telegram notifier checks: once per weekday per brief, after
            # each brief's own send window - confirm the 9:30 AM stock brief
            # and, separately, the 10:30 AM options brief actually went out.
            today_str = now_et.strftime("%Y-%m-%d")
            is_weekday = now_et.weekday() < 5

            past_stock_window = (now_et.hour, now_et.minute) >= (9, 35)
            if is_weekday and past_stock_window and aiem_stock_alert_sent_date != today_str:
                ok, detail = _check_aiem_notifier("stock")
                if ok:
                    print(f"[monitor] {now_str} — AIEM stock notifier OK ({detail})")
                else:
                    print(f"[monitor] {now_str} — AIEM stock notifier FAILED ({detail})")
                    _send_aiem_failure_alert("stock", detail, now_str)
                aiem_stock_alert_sent_date = today_str  # one check/alert per day, not one per 30-min tick

            past_options_window = (now_et.hour, now_et.minute) >= (10, 35)
            if is_weekday and past_options_window and aiem_options_alert_sent_date != today_str:
                ok, detail = _check_aiem_notifier("options")
                if ok:
                    print(f"[monitor] {now_str} — AIEM options notifier OK ({detail})")
                else:
                    print(f"[monitor] {now_str} — AIEM options notifier FAILED ({detail})")
                    _send_aiem_failure_alert("options", detail, now_str)
                aiem_options_alert_sent_date = today_str  # one check/alert per day, not one per 30-min tick

        time.sleep(SLEEP_TICK)


def run_once():
    """Execute both checks a single time and exit. For manual verification -
    not used by the production loop, which is `run()` above."""
    now_et = datetime.now(ET)
    now_str = now_et.strftime("%a %b %d %I:%M %p ET")

    up = _ping()
    print(f"[monitor] {now_str} — site ping: {'UP' if up else 'DOWN'} ({CHECK_URL})")

    for brief_type in ("stock", "options"):
        ok, detail = _check_aiem_notifier(brief_type)
        print(f"[monitor] {now_str} — AIEM {brief_type} notifier check against {AIEM_HEALTH_URL}: ok={ok} detail={detail!r}")
        if ok:
            print(f"[monitor] AIEM {brief_type} notifier OK — no alert sent")
        else:
            print(f"[monitor] AIEM {brief_type} notifier FAILED — sending alert email to {OWNER_EMAIL}")
            _send_aiem_failure_alert(brief_type, detail, now_str)


if __name__ == "__main__":
    import sys
    if "--once" in sys.argv:
        run_once()
    else:
        run()

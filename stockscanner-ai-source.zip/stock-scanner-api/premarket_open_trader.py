"""
premarket_open_trader.py
====================================================================
Combines opening-snapshot pattern classification with TODAY's other
verified modules (synthesis confluence, earnings buffer, correlation
risk, regime, slippage) into ONE final decision: enter_now,
wait_until_945, or skip. If entering, writes a real PAPER pick to
ai_stock_picks.

This is the orchestration layer — the piece that combines separate
checks into one verdict instead of leaving you to read six numbers
and decide yourself.

SAFETY GATES (Group 1, wired 2026-07-03)
-----------------------------------------
Four hard-stop checks run before any paper pick is ever written:

  1. position_reconciler  — unresolved broker/DB mismatch → skip
  2. daily_loss_limit     — today's loss exceeds threshold → skip
                            IMPORTANT: fails CLOSED when
                            ACCOUNT_VALUE_BASELINE env var is not set.
                            Set it (e.g. ACCOUNT_VALUE_BASELINE=50000)
                            or every trade is blocked by design.
  3. portfolio_correlation_risk — too many correlated positions → skip
  4. order_dedup          — same decision_id attempted twice → skip

Hard gates:  ANY single hit forces decision="skip", no pick written.
Soft gates:  2+ soft hits force skip; 1 soft hit → wait_until_945.
====================================================================
"""

import datetime as dt
import os
from typing import Dict, Any, List, Optional

import psycopg2
import decision_logger as dl
import opening_snapshot_tracker as ost
import pre_recommendation_synthesis as prs
import earnings_calendar as ec
import regime_detector as rd
import regime_macro_patch as rmp
import news_catalyst_monitor as ncm
# position_reconciler removed — reconcile_positions() is never scheduled
# (mock broker only, no real account/positions API exists yet). Re-enable
# when a real get_broker_positions() is wired in. See incident 2026-06-28.
import daily_loss_limit as dll
import order_dedup as od
import portfolio_correlation_risk as pcr
import kill_switch as ks

BASE_PAPER_POSITION_USD = 1_000
_CONFIDENCE_SCORE_MAP   = {"high": 0.85, "medium": 0.60, "low": 0.40}

# Bounded-exit parameters — every paper pick must have a stop and target at entry.
# stop_pct is confidence-independent (-5% hard stop).
# target_pct is confidence-tiered (high = 3:1 R:R, medium/low = 2:1 R:R).
# hold_days caps the position regardless of stop/target (matches table default of 3).
_PAPER_STOP_PCT    = -5.0
_PAPER_TARGET_PCTS = {"high": 15.0, "medium": 10.0, "low": 8.0}
_PAPER_HOLD_DAYS   = 3

_DECISION_TYPE_MAP = {
    "enter_now":      "trade",
    "wait_until_945": "no_trade",
    "skip":           "no_trade",
}


def init_schema(db_url: str = None) -> None:
    """
    Creates the tables required by the safety gate modules.
    Call once at startup (wired into _DEFERRED_INITS in main.py).
    Idempotent — safe to call on every boot.
    """
    if db_url is None:
        db_url = os.environ.get("DATABASE_URL")
    if not db_url:
        print("[premarket_open_trader] init_schema: DATABASE_URL not set, skipping")
        return

    statements = [
        """
        CREATE TABLE IF NOT EXISTS order_execution_log (
            id              SERIAL PRIMARY KEY,
            decision_id     INTEGER NOT NULL,
            broker_order_id TEXT,
            ticker          TEXT,
            side            TEXT,
            qty             DOUBLE PRECISION,
            status          TEXT,
            submitted_at    TIMESTAMPTZ NOT NULL,
            filled_at       TIMESTAMPTZ,
            fill_price      DOUBLE PRECISION,
            UNIQUE (decision_id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS daily_loss_breach_log (
            id              SERIAL PRIMARY KEY,
            checked_at      TIMESTAMPTZ NOT NULL,
            account_value   DOUBLE PRECISION,
            realized_pnl    DOUBLE PRECISION,
            loss_pct        DOUBLE PRECISION,
            loss_limit_pct  DOUBLE PRECISION,
            resolved        BOOLEAN DEFAULT FALSE
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS reconciliation_log (
            id              SERIAL PRIMARY KEY,
            checked_at      TIMESTAMPTZ NOT NULL,
            only_in_broker  TEXT,
            only_in_db      TEXT,
            mismatch_found  BOOLEAN,
            resolved        BOOLEAN DEFAULT FALSE
        )
        """,
    ]

    conn = psycopg2.connect(db_url)
    try:
        with conn.cursor() as cur:
            for sql in statements:
                cur.execute(sql)
        conn.commit()
        print("[premarket_open_trader] init_schema: safety gate tables verified/created")
    except Exception as exc:
        print(f"[premarket_open_trader] init_schema error: {exc}")
    finally:
        conn.close()


def classify_from_snapshots(snapshots: List[Dict[str, Any]],
                              premarket_gap_pct: float) -> Dict[str, Any]:
    """Same classification logic as before, fed by accumulated
    snapshots instead of a dedicated minute-bar feed."""
    if len(snapshots) < 3:
        return {"pattern": "insufficient_data", "confidence": "low",
                "recommendation": "wait_for_more_scans"}

    open_price    = snapshots[0]["price"]
    current_price = snapshots[-1]["price"]
    high_so_far   = max(s["price"] for s in snapshots)
    low_so_far    = min(s["price"] for s in snapshots)

    move_from_open_pct     = ((current_price - open_price) / open_price) * 100 if open_price else 0
    pulled_back_pct        = ((high_so_far - low_so_far) / high_so_far) * 100 if high_so_far else 0
    recovered_from_low_pct = ((current_price - low_so_far) / low_so_far) * 100 if low_so_far else 0

    is_gap_up = premarket_gap_pct > 0

    if is_gap_up:
        if current_price < open_price and move_from_open_pct < -1.0:
            pattern    = "fake_breakout"
            confidence = "medium" if move_from_open_pct < -2.0 else "low"
        elif pulled_back_pct > 1.5 and recovered_from_low_pct > 1.0 and current_price >= open_price * 0.99:
            pattern, confidence = "pullback_continuation", "medium"
        elif current_price >= open_price:
            pattern    = "genuine_continuation"
            confidence = "medium" if move_from_open_pct > 0.5 else "low"
        else:
            pattern, confidence = "ambiguous", "low"
    else:
        if current_price > open_price and move_from_open_pct > 1.0:
            pattern    = "fake_breakdown"
            confidence = "medium" if move_from_open_pct > 2.0 else "low"
        elif pulled_back_pct > 1.5 and current_price <= open_price * 1.01:
            pattern, confidence = "pullback_breakdown", "medium"
        elif current_price <= open_price:
            pattern    = "genuine_breakdown"
            confidence = "medium" if move_from_open_pct < -0.5 else "low"
        else:
            pattern, confidence = "ambiguous", "low"

    return {
        "pattern":                pattern,
        "confidence":             confidence,
        "move_from_open_pct":     round(move_from_open_pct, 3),
        "pulled_back_pct":        round(pulled_back_pct, 3),
        "recovered_from_low_pct": round(recovered_from_low_pct, 3),
        "n_snapshots":            len(snapshots),
    }


def evaluate_ticker(db_url: str, ticker: str, premarket_gap_pct: float) -> Dict[str, Any]:
    """
    THE FULL COMBINED DECISION. Pulls every relevant check and
    produces ONE verdict, with the reasoning trail showing which
    factors drove it.

    Gate order:
      Hard gates run first (any one → skip, no pick written):
        1. earnings risk
        2. unresolved position mismatch
        3. daily loss limit breached
        4. portfolio concentration risk

      Soft gates run next (2+ → skip, 1 → wait_until_945):
        5. opening pattern is a fake move
        6. opening behavior still ambiguous
        7. weak signal confluence
        8. defensive market regime
    """
    hard_blockers: List[str] = []
    soft_blockers: List[str] = []

    try:
        snapshots = ost.get_todays_snapshots(db_url, ticker)
        opening_pattern = classify_from_snapshots(snapshots, premarket_gap_pct)
    except Exception as _exc:
        hard_blockers.append(f"snapshot fetch failed (fail closed — DB unreachable?): {_exc}")
        snapshots = []
        opening_pattern = {"pattern": "insufficient_data", "confidence": "low", "n_snapshots": 0}

    try:
        synthesis = prs.synthesize_and_log(db_url, ticker)
    except Exception as _exc:
        hard_blockers.append(f"signal synthesis failed (fail closed): {_exc}")
        synthesis = {"confluence_count": 0}

    try:
        regime = rd.get_current_regime(db_url, "SPY")
    except Exception as _exc:
        hard_blockers.append(f"regime check failed (fail closed): {_exc}")
        regime = {}

    # ── HARD GATE 1: earnings risk ────────────────────────────────────
    try:
        earnings = ec.should_avoid_entry(db_url, ticker, buffer_days=2)
        if earnings.get("avoid"):
            hard_blockers.append(f"earnings risk: {earnings['reason']}")
    except Exception as _exc:
        hard_blockers.append(f"earnings calendar check failed (fail closed): {_exc}")
        earnings = {}

    # ── HARD GATE 2: unresolved broker/DB position mismatch (disabled) ──
    # position_reconciler not imported — reconcile_positions() is never scheduled
    # (mock broker only). Re-enable when a real get_broker_positions() exists.
    # See incident 2026-06-28 for why the mock must never run in production.

    # ── HARD GATE 3: daily loss limit ────────────────────────────────
    try:
        dll_result = dll.check_daily_loss_limit(db_url)
        if dll_result["halt_trading"]:
            loss_pct   = dll_result.get("loss_pct")
            limit_pct  = dll_result.get("loss_limit_pct")
            reason     = dll_result.get("reason") or ""
            if loss_pct is not None:
                hard_blockers.append(
                    f"daily loss limit breached: {loss_pct}% (limit -{limit_pct}%)"
                )
            else:
                hard_blockers.append(
                    f"daily loss limit check failed (fail closed): {reason[:120]}"
                )
    except Exception as _exc:
        hard_blockers.append(f"daily loss limit check raised exception (fail closed): {_exc}")

    # ── HARD GATE 4: portfolio concentration risk ─────────────────────
    try:
        correlation_result = pcr.check_current_portfolio_risk(db_url)
        if correlation_result["concentration_risk_flag"]:
            hard_blockers.append(
                f"portfolio concentration risk: {correlation_result['warnings']}"
            )
    except Exception as _exc:
        hard_blockers.append(f"portfolio correlation check failed (fail closed): {_exc}")

    # ── HARD GATE 5: high-impact macro event today ────────────────────
    try:
        macro_result = rmp.get_regime_with_macro_overlay(db_url, "SPY")
        if macro_result["high_impact_macro_day"]:
            hard_blockers.append(
                f"high-impact macro event today: {macro_result['macro_events_today']}"
            )
    except Exception as _exc:
        hard_blockers.append(f"macro overlay check failed (fail closed): {_exc}")

    # ── HARD GATE 6: high-risk headline for this ticker ───────────────
    try:
        headline_check = ncm.check_recent_headlines(db_url, ticker)
        if headline_check["high_risk_flag"]:
            hard_blockers.append(
                f"high-risk headline flagged: {headline_check['flagged_headlines']}"
            )
    except Exception as _exc:
        hard_blockers.append(f"news catalyst check failed (fail closed): {_exc}")

    # ── HARD GATE 7: kill switch — metrics evaluation + halt write + read
    # Derives equity and trade metrics unconditionally from ai_stock_picks
    # + ACCOUNT_VALUE_BASELINE; calls check_kill_switch() which evaluates
    # the limits AND writes the halt to the DB if breached — all in one
    # pass, no AIEM agent involvement required.
    try:
        _ks_baseline = dll.get_account_value(db_url)
        if not _ks_baseline:
            hard_blockers.append(
                "kill switch evaluation skipped (fail closed): "
                "ACCOUNT_VALUE_BASELINE not configured or invalid"
            )
        else:
            _ks_db = psycopg2.connect(db_url)
            try:
                with _ks_db.cursor() as _cur:
                    _cur.execute("""
                        SELECT COALESCE(SUM(exit_price - score), 0.0)
                        FROM ai_stock_picks
                        WHERE status = 'closed' AND exit_price IS NOT NULL
                    """)
                    _ks_alltime_pnl = float(_cur.fetchone()[0])
                    _cur.execute(
                        "SELECT COUNT(*) FROM ai_stock_picks WHERE pick_date = CURRENT_DATE"
                    )
                    _ks_trades_today = int(_cur.fetchone()[0])
                    _cur.execute("""
                        SELECT (exit_price - score)
                        FROM ai_stock_picks
                        WHERE status = 'closed' AND exit_price IS NOT NULL
                        ORDER BY closed_at DESC LIMIT 20
                    """)
                    _ks_consec = 0
                    for (_pnl,) in _cur.fetchall():
                        if float(_pnl) < 0:
                            _ks_consec += 1
                        else:
                            break
            finally:
                _ks_db.close()

            _ks_result = ks.check_kill_switch(
                signal_name="premarket_open_trader",
                current_equity=float(_ks_baseline) + _ks_alltime_pnl,
                peak_equity=float(_ks_baseline),
                trades_today=_ks_trades_today,
                consecutive_losses=_ks_consec,
                total_trades_this_window=_ks_trades_today,
            )
            if _ks_result.get("halted"):
                hard_blockers.append(
                    f"kill switch halted: {_ks_result.get('reason', '')}"
                )
    except Exception as _exc:
        hard_blockers.append(f"kill switch evaluation failed (fail closed): {_exc}")

    # ── HARD GATE 8: simulation lock — paper-mode guard ───────────────
    # assert_simulation_mode() raises LiveTradingBlockedError when all
    # three live-trading env vars are correctly configured. Any exception
    # here fails closed — the gate is structural, not advisory.
    try:
        from simulation_lock import assert_simulation_mode
        assert_simulation_mode("premarket_open_trader")
    except Exception as _exc:
        hard_blockers.append(
            f"simulation lock blocked: premarket_open_trader is paper-only. "
            f"[{type(_exc).__name__}] {_exc}"
        )

    # ── SOFT GATES ────────────────────────────────────────────────────
    if opening_pattern["pattern"] in ("fake_breakout", "fake_breakdown"):
        soft_blockers.append(
            f"opening pattern looks like a fake move ({opening_pattern['pattern']})"
        )
    if opening_pattern["confidence"] == "low" or \
       opening_pattern["pattern"] in ("ambiguous", "insufficient_data"):
        soft_blockers.append("opening behavior still ambiguous, not enough signal yet")
    if synthesis["confluence_count"] < 2:
        soft_blockers.append(f"weak signal confluence ({synthesis['confluence_count']}/4)")
    if regime.get("regime") in ("high_vol_downtrend",) or \
       (regime.get("confidence") == "low" and regime.get("total_score", 0) < 0):
        soft_blockers.append("defensive market regime")

    # ── DECISION ──────────────────────────────────────────────────────
    if hard_blockers:
        decision = "skip"
    elif len(soft_blockers) >= 2:
        decision = "skip"
    elif soft_blockers:
        decision = "wait_until_945"
    elif opening_pattern["pattern"] in ("genuine_continuation", "genuine_breakdown") \
         and opening_pattern["confidence"] == "medium":
        decision = "enter_now"
    else:
        decision = "wait_until_945"

    all_blockers = hard_blockers + soft_blockers

    result = {
        "ticker":               ticker,
        "decision":             decision,
        "opening_pattern":      opening_pattern,
        "synthesis_confluence": synthesis["confluence_count"],
        "earnings_check":       earnings,
        "regime":               regime.get("regime"),
        "hard_blockers":        hard_blockers,
        "soft_blockers":        soft_blockers,
        "blockers":             all_blockers,
        "checked_at":           dt.datetime.utcnow().isoformat(),
    }

    reasoning = (
        f"PREMARKET/OPEN DECISION for {ticker}: {decision.upper()}. "
        f"Opening pattern: {opening_pattern['pattern']} "
        f"(confidence {opening_pattern['confidence']}, "
        f"{opening_pattern.get('n_snapshots', 0)} scans observed). "
        f"Synthesis confluence: {synthesis['confluence_count']}/4. "
        f"Hard blockers: {hard_blockers if hard_blockers else 'none'}. "
        f"Soft blockers: {soft_blockers if soft_blockers else 'none'}."
    )

    decision_id: Optional[int] = None
    try:
        decision_id = dl.log_decision(
            signal_name="premarket_open_trader",
            decision_type=_DECISION_TYPE_MAP.get(decision, "no_trade"),
            ticker=ticker,
            reasoning=reasoning,
        )
    except Exception as _e:
        print(f"[premarket_open_trader] log_decision failed: {_e}")

    if decision == "enter_now":
        _conn_chk = psycopg2.connect(db_url)
        try:
            with _conn_chk.cursor() as _cur:
                _cur.execute(
                    "SELECT COUNT(*) FROM ai_stock_picks WHERE ticker=%s AND pick_date=CURRENT_DATE",
                    (ticker,)
                )
                _ticker_already_picked = _cur.fetchone()[0] > 0
        finally:
            _conn_chk.close()

        if _ticker_already_picked:
            print(
                f"[premarket_open_trader] ticker-day dedup: {ticker} already has a pick today "
                f"— skipping to prevent duplicate order_execution_log entry"
            )
        elif decision_id is None:
            print(
                f"[premarket_open_trader] WARNING: decision_id is None for {ticker} "
                f"(log_decision failed) — skipping write to preserve dedup guarantee"
            )
        elif od.should_place_order(db_url, decision_id):
            # ── G2 pre-decision trace-integrity checkpoint (Path B P4) ────
            # This module never runs candidates through the Diagram 2
            # 1-17 stage pipeline (it is a separate opening-pattern
            # decision path, not the `_aiem_paper_execute_today` engine),
            # so candidate_trace_id is honestly None every time -- G2
            # will report NO_TRACE_ID rather than fabricate STAGES_COMPLETE.
            # While G2 is in SHADOW mode (the only mode it runs in today)
            # this can never actually skip a write -- it only records what
            # an ENFORCE-mode gate would have done, surfacing the real fact
            # that this write path bypasses D2 stage tracking entirely.
            try:
                import aiem_diagram3_governance as _d3_g2_pot
                _g2_pot_result = _d3_g2_pot.require_governance_authorization(
                    checkpoint="G2",
                    entrypoint="premarket_open_trader.evaluate_ticker",
                    run_kind="TRADE_EXECUTING",
                    source_phase="decision_engine",
                    trigger_source="scheduled_premarket_open_tracker",
                    payload={"ticker": ticker, "diagram2_trace_id": None},
                    candidate_trace_id=None,
                    candidate_ticker=ticker,
                    is_test_record=False,
                )
            except Exception as _g2_pot_e:
                print(f"[premarket_open_trader] G2 checkpoint itself raised for {ticker} — "
                      f"fail-closed BLOCK: {_g2_pot_e}")
                _g2_pot_result = {"decision": "BLOCK", "reason_code": f"G2_CHECK_EXCEPTION:{_g2_pot_e}",
                                   "mode": "UNKNOWN", "system_state": "UNKNOWN", "would_block": True,
                                   "governance_decision_id": None}

            _g2_pot_gdid = _g2_pot_result.get("governance_decision_id")

            if _g2_pot_result.get("decision") == "BLOCK":
                print(f"[premarket_open_trader] G2 BLOCKED candidate {ticker} — "
                      f"{_g2_pot_result.get('reason_code')} "
                      f"(system_state={_g2_pot_result.get('system_state')}, "
                      f"checkpoint_mode={_g2_pot_result.get('mode')})")
                if _g2_pot_gdid:
                    try:
                        _d3_g2_pot.acknowledge_governance_decision(
                            governance_decision_id=_g2_pot_gdid,
                            action_taken="CANDIDATE_SKIPPED_G2",
                            continued=False,
                            blocked=True,
                            acknowledged_by="premarket_open_trader.evaluate_ticker",
                            is_test_record=False,
                        )
                    except Exception as _g2_pot_ack_e:
                        print(f"[premarket_open_trader] G2 ack (BLOCK) failed, non-fatal: {_g2_pot_ack_e}")
                # G2 BLOCK skips only this candidate's write -- no lock held
                # in this branch, mirrors the main.py G2 call site pattern.
            else:
                if _g2_pot_result.get("would_block"):
                    print(f"[premarket_open_trader] G2 SHADOW: would have blocked candidate "
                          f"{ticker} — {_g2_pot_result.get('reason_code')} "
                          f"(ledger_event_id={_g2_pot_result.get('ledger_event_id')})")
                if _g2_pot_gdid:
                    try:
                        _d3_g2_pot.acknowledge_governance_decision(
                            governance_decision_id=_g2_pot_gdid,
                            action_taken="PROCEEDING_WITH_CANDIDATE",
                            continued=True,
                            blocked=False,
                            acknowledged_by="premarket_open_trader.evaluate_ticker",
                            is_test_record=False,
                        )
                    except Exception as _g2_pot_ack_e:
                        print(f"[premarket_open_trader] G2 ack (ALLOW) failed, non-fatal: {_g2_pot_ack_e}")

            # ── G3 pre-execution governance authorization (Path B P5) ──────
            # This module's own hard/soft blocker gates (od.should_place_order,
            # opening-pattern confluence, dedup) already ran before this call
            # site — that IS this path's real risk determination, so
            # diagram2_risk_result="PASS" is honest here, not assumed.
            # execution_mode="PAPER" (no live broker adapter exists in this
            # codebase). strategy_version="premarket_open_trader" is checked
            # against d3_strategy_registry — as of this writing that name has
            # never been registered there, so G3 will honestly report
            # UNAPPROVED_STRATEGY:premarket_open_trader; a real, pre-existing
            # gap this checkpoint surfaces in SHADOW mode, not one this
            # change papers over. model_version is honestly None (this path
            # is opening-pattern/confluence-driven, not model-scored).
            try:
                import aiem_diagram3_governance as _d3_g3_pot
                _g3_pot_result = _d3_g3_pot.require_governance_authorization(
                    checkpoint="G3",
                    entrypoint="premarket_open_trader.evaluate_ticker",
                    run_kind="TRADE_EXECUTING",
                    source_phase="decision_engine",
                    trigger_source="scheduled_premarket_open_tracker",
                    payload={"ticker": ticker, "diagram2_trace_id": None},
                    candidate_trace_id=None,
                    candidate_ticker=ticker,
                    diagram2_risk_result="PASS",
                    execution_mode="PAPER",
                    strategy_version="premarket_open_trader",
                    model_version=None,
                    is_test_record=False,
                )
            except Exception as _g3_pot_e:
                print(f"[premarket_open_trader] G3 checkpoint itself raised for {ticker} — "
                      f"fail-closed BLOCK: {_g3_pot_e}")
                _g3_pot_result = {"decision": "BLOCK", "reason_code": f"G3_CHECK_EXCEPTION:{_g3_pot_e}",
                                   "mode": "UNKNOWN", "system_state": "UNKNOWN", "would_block": True,
                                   "governance_decision_id": None}

            _g3_pot_gdid = _g3_pot_result.get("governance_decision_id")

            if _g3_pot_result.get("decision") == "BLOCK":
                print(f"[premarket_open_trader] G3 BLOCKED candidate {ticker} — "
                      f"{_g3_pot_result.get('reason_code')} "
                      f"(system_state={_g3_pot_result.get('system_state')}, "
                      f"checkpoint_mode={_g3_pot_result.get('mode')})")
                if _g3_pot_gdid:
                    try:
                        _d3_g3_pot.acknowledge_governance_decision(
                            governance_decision_id=_g3_pot_gdid,
                            action_taken="CANDIDATE_SKIPPED_G3",
                            continued=False,
                            blocked=True,
                            acknowledged_by="premarket_open_trader.evaluate_ticker",
                            is_test_record=False,
                        )
                    except Exception as _g3_pot_ack_e:
                        print(f"[premarket_open_trader] G3 ack (BLOCK) failed, non-fatal: {_g3_pot_ack_e}")
                # G3 BLOCK skips only this candidate's write, mirroring the G2
                # call site above — no lock held in this branch.
            else:
                if _g3_pot_result.get("would_block"):
                    print(f"[premarket_open_trader] G3 SHADOW: would have blocked candidate "
                          f"{ticker} — {_g3_pot_result.get('reason_code')} "
                          f"(ledger_event_id={_g3_pot_result.get('ledger_event_id')})")
                if _g3_pot_gdid:
                    try:
                        _d3_g3_pot.acknowledge_governance_decision(
                            governance_decision_id=_g3_pot_gdid,
                            action_taken="PROCEEDING_WITH_CANDIDATE",
                            continued=True,
                            blocked=False,
                            acknowledged_by="premarket_open_trader.evaluate_ticker",
                            is_test_record=False,
                        )
                    except Exception as _g3_pot_ack_e:
                        print(f"[premarket_open_trader] G3 ack (ALLOW) failed, non-fatal: {_g3_pot_ack_e}")
                write_paper_pick(db_url, ticker, opening_pattern, synthesis, regime=regime)
                od.mark_order_placed(
                    db_url, decision_id,
                    broker_order_id=f"paper-{decision_id}",
                    ticker=ticker, side="long", qty=1, status="filled",
                )
        else:
            print(
                f"[premarket_open_trader] duplicate blocked: "
                f"decision_id={decision_id} already in order_execution_log"
            )

    result["decision_id"] = decision_id
    return result


def write_paper_pick(db_url: str, ticker: str, opening_pattern: Dict[str, Any],
                      synthesis: Dict[str, Any],
                      regime: Dict[str, Any] = None) -> None:
    """Writes a paper-trade row to ai_stock_picks.
    Applies regime multipliers so paper position size and confidence score
    reflect the current market environment, not just the per-ticker signal.
    """
    import json as _json
    multipliers  = (regime or {}).get("multipliers") or {}
    pos_mult     = float(multipliers.get("position_size_multiplier", 1.0))
    conf_mult    = float(multipliers.get("confidence_multiplier",    1.0))
    base_conf    = _CONFIDENCE_SCORE_MAP.get(opening_pattern["confidence"], 0.5)
    adj_conf     = round(min(1.0, base_conf * conf_mult), 4)
    pos_size_usd = round(BASE_PAPER_POSITION_USD * pos_mult, 2)
    regime_rec   = (regime or {}).get("recommendation", "unknown")

    note = (
        f"PAPER ENTRY (premarket_open_trader): "
        f"pattern={opening_pattern['pattern']}, "
        f"confluence={synthesis['confluence_count']}/4, "
        f"regime={regime_rec}, pos_size=${pos_size_usd:.0f}"
    )
    import datetime as _dt
    stop_pct   = _PAPER_STOP_PCT
    target_pct = _PAPER_TARGET_PCTS.get(opening_pattern.get("confidence", "medium"), 10.0)
    hold_days  = _PAPER_HOLD_DAYS
    exit_date  = _dt.date.today() + _dt.timedelta(days=hold_days)

    signals_json = {
        "position_size_usd":        pos_size_usd,
        "position_size_multiplier": pos_mult,
        "confidence_multiplier":    conf_mult,
        "regime_recommendation":    regime_rec,
        "base_confidence":          base_conf,
        "adjusted_confidence":      adj_conf,
        "stop_pct":                 stop_pct,
        "target_pct":               target_pct,
        "hold_days":                hold_days,
    }
    conn = psycopg2.connect(db_url)
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO ai_stock_picks
                    (ticker, status, pick_date, entry_note, confidence, score, signals,
                     stop_pct, target_pct, hold_days, exit_date)
                VALUES (%s, 'open', CURRENT_DATE, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (pick_date, ticker) DO NOTHING
            """, (ticker, note, opening_pattern["confidence"],
                  adj_conf, _json.dumps(signals_json),
                  stop_pct, target_pct, hold_days, exit_date))
        conn.commit()
    finally:
        conn.close()


if __name__ == "__main__":
    import os
    db_url = os.environ.get("DATABASE_URL")
    if db_url:
        print(evaluate_ticker(db_url, "AAPL", premarket_gap_pct=4.5))
    else:
        print("Set DATABASE_URL to test.")

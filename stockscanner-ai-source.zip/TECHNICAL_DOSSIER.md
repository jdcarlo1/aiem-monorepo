# StockScanner AI — Technical Review Dossier
**Package date:** 2026-07-26  
**Last commit:** e5eb9f9043d7f88c43424d2c774ca35ae85c35e9  
**Commit message:** "Update record to confirm decision on minimum history value"

---

## 1. Repo Export

This zip (`stockscanner-ai-source.zip`) contains:

| Folder | Contents |
|---|---|
| `stock-scanner-api/` | 149 Python files — Flask API, scanner modules, ML pipeline, signals |
| `stock-scanner-api/patterns/` | 2 files — `zero_dte_sweep.py` (0DTE scanner added 2026-07-26), `__init__.py` |
| `stock-scanner-web/` | 77 files — React/TypeScript/Vite frontend |

**What is NOT included** (excluded intentionally):
- `aiem_*.py` — 108 files (76,933 lines): the AIEM Institutional AI engine, a separate product
- `ase_*.py`, `verify_*.py`, `strict_*.py` — 44 files: options assignment strategy engine + verification infrastructure
- `dpl/` subdirectory: decision provenance logging for the institutional engine
- `tools/` subdirectory: verification toolchain for the institutional engine
- Old zip archives that were sitting in `public/`

**Important note on `main.py`:** The Flask API is a 70,851-line monolith. It contains both stock scanner endpoints and AIEM institutional endpoints mixed together. A clean separation into microservices has not been done. A buyer/reviewer should be aware that the AIEM logic is interleaved throughout `main.py`, even though its supporting modules (`aiem_*.py`) are excluded from this export.

---

## 2. Architecture Overview

### Tech Stack
| Layer | Technology |
|---|---|
| Backend API | Python 3.11 + Flask (single monolith: `main.py`) |
| Frontend | React 18 + TypeScript + Vite (`artifacts/stock-scanner/`) |
| Database | PostgreSQL (Replit managed, psycopg2 direct + connection pool) |
| Scheduler | APScheduler (embedded in `main.py`; also separate `aiem_process.py`) |
| ML | XGBoost (`ml_engine.py`, `model_training.py`) |
| Encryption | `cryptography.fernet` (Fernet/AES-128-CBC) for BYOK key storage |
| Options math | Custom Black-Scholes (`patterns/zero_dte_sweep.py`, `aiem_optprob.py`) |
| Email | SMTP via `email_alerts.py` |
| Alerts | Telegram bot (`telegram_charts.py`) |

### Main Modules / Services

```
artifacts/stock-scanner-api/
├── main.py                      # 70,851-line Flask monolith — all API routes + schedulers
├── scanner.py                   # Core ticker screening logic
├── scoring.py                   # Scoring utilities / normalization helpers
├── indicators.py                # Technical indicators (RSI, MACD, ADX, etc.)
├── patterns/
│   └── zero_dte_sweep.py        # 0DTE options pattern scanner (added 2026-07-26)
│
├── ── Signal modules ──
├── smart_money.py               # Dark pool + block trade detection (1,383 lines)
├── options_sweep.py             # Unusual call sweep detector
├── layer9_statistical_edge.py   # Layer 9 quant edge (Hurst, VPIN, Amihud, VRP)
├── advanced_quant_indicators.py # Microstructure indicators
├── candlestick_patterns.py      # Pattern recognition
├── price_structure_patterns.py  # Support/resistance, breakout structure
│
├── ── Data sources ──
├── fred_macro.py                # FRED macroeconomic data
├── social_sentiment.py          # Social sentiment
├── reddit_sentiment.py          # Reddit/WallStreetBets sentiment
├── insider_trades.py            # SEC insider filing data
├── congress_trades.py           # Congressional trading disclosures
├── news_catalyst.py             # News event detection
├── earnings_calendar.py         # Earnings date tracking
│
├── ── ML pipeline ──
├── ml_engine.py                 # XGBoost predict/score wrapper
├── ml_infrastructure.py         # Training infrastructure
├── model_training.py            # Model training pipeline
├── alpha_historical_trainer.py  # Historical alpha training
├── alpha_train_pipeline.py      # End-to-end training pipeline
│
├── ── Portfolio / risk ──
├── portfolio.py                 # Portfolio tracking
├── paper_performance.py         # Paper trade P&L and analytics
├── daily_loss_limit.py          # Daily loss circuit breaker
├── pre_decision_risk_gate.py    # Pre-trade risk checks
├── position_sizing.py           # Kelly / fixed-fraction sizing
├── slippage_model.py            # Square-root market impact model
│
├── ── Regime / macro overlay ──
├── regime_detector.py           # Market regime classifier (15-min cache)
├── regime_monitor.py            # Regime change monitoring
├── market_regime_overlay.py     # Applies regime to all scan output
├── volatility_clustering.py     # Vol regime detection
├── macro_cross_asset.py         # Cross-asset macro signals
│
├── ── Backtesting ──
├── backtest.py                  # Core walk-forward backtest harness
├── backtest_*.py                # 14 scenario-specific backtest scripts
│
artifacts/stock-scanner/ (React frontend)
├── src/pages/Dashboard.tsx      # Main scanner dashboard (1,082 lines)
├── src/pages/Landing.tsx        # Landing / marketing page
├── src/lib/api.ts               # API client helpers
└── src/components/              # Shared UI components
```

### How It Connects

```
User Browser
    │
    ▼
React/Vite Frontend (port from $PORT env)
    │  REST + SSE
    ▼
Flask API  main.py  (port 5055 default)
    ├── APScheduler jobs (embedded)
    │     ├── 8:35 AM  Polygon RVOL full-market scan (11k+ tickers)
    │     ├── 9:10 AM  Stat-arb pair scan
    │     ├── 9:35 AM  Nano/small-cap morning watch
    │     ├── 9:45 AM  Layer 9 score batch
    │     ├── 9:45 AM  _run_five_layer_conviction scan
    │     ├── 10:00–11:30 AM / 2:00–3:30 PM  0DTE sweep (5-min)
    │     └── 4:00 PM  EOD MTM + learning loop
    │
    ├── PostgreSQL (DATABASE_URL)
    │     └── ~120+ tables: polygon_rvol_scan, gamma_pressure_alerts,
    │           call_sweep_log, sm_subscribers, ai_stock_picks, ...
    │
    ├── Polygon.io  (POLYGON_API_KEY)
    ├── Tradier     (TRADIER_API_TOKEN_2 → TOKEN)
    ├── FINRA ATS   (public dark pool feed)
    ├── yfinance    (rate-limited, secondary)
    └── OpenAI/Anthropic (via BYOK or platform key)
```

---

## 3. 8-Layer Conviction Scoring — Actual Code

**Function:** `_run_five_layer_conviction()` in `main.py` starting at line 22,333  
**Note:** Named "5-layer" historically but now has 8 active scoring layers plus a regime multiplier and two modifiers (Layer 10 fragility penalty, M7 sector rotation bonus).

### Scoring Formula
```
total_pts = sum of all layer pts
adj_total = total_pts × regime_multiplier   (0.70–1.00 depending on regime)
conviction_pct = min(95, adj_total / 10.0 × 95)
label = EXTREME (≥8 adj_pts) | HIGH (≥6) | ELEVATED (≥4) | MODERATE (<4)
```

### Layer 1: OI Accumulation
```python
# Source: options OI % change day-over-day
# Data:   _get_oi_accumulation_signals(days_back=1)
oi_f = float(oi_pct or 0)
pts  = 2.0 if oi_f >= 50 else 1.5 if oi_f >= 25 else 1.0
scores[ticker]["pts"]["oi_accum"] = pts
```

### Layer 2: Gamma FIR (Gamma Flip Impact Ratio)
```python
# Source: gamma_pressure_alerts table (populated by intraday gamma scan)
# Data:   today's MAX(fir) per ticker
fir = float(max_fir or 0)
pts = 2.0 if fir >= 5 else 1.5 if fir >= 3 else 1.0
scores[ticker]["pts"]["gamma_fir"] = pts
```

### Layer 3: Charm Cascade
```python
# Source: _get_charm_cascade_signals()
# charm_score = delta-decay acceleration across the OI chain
cs  = float(charm_score or 0)
pts = 2.0 if cs >= 1000 else 1.5 if cs >= 400 else 1.0
scores[ticker]["pts"]["charm"] = max(existing, pts)
```

### Layer 4: Short Interest
```python
# Source: _get_short_interest(active) — Finviz scrape, cached
si_pct = si["si_pct"]          # short interest as % of float
dtc    = si["dtc"]             # days-to-cover
pts    = 2.0 if si_pct >= 20 else 1.5 if si_pct >= 15 else 1.0 if si_pct >= 8 else 0.0
scores[ticker]["pts"]["short_int"] = pts
```

### Layer 5: Dark Pool Convergence
```python
# Source: _get_dark_pool_convergence(active) — FINRA ATS off-exchange %
dp_pct = dp["off_exchange_pct"]
pts    = 2.0 if dp_pct >= 60 else 1.5 if dp_pct >= 50 else 1.0 if dp_pct >= 40 else 0.0
scores[ticker]["pts"]["dark_pool"] = pts
```

### Layer 6: Float-Adjusted Options Demand
```python
# Source: _get_float_pressure_signals(active)
# pressure_pct = call_oi / float_shares × 100
# float_m = float shares in millions
if fp["l6_pts"] > 0:
    scores[ticker]["pts"]["float_pressure"] = fp["l6_pts"]
    scores[ticker]["meta"]["float_pressure_pct"] = fp["pressure_pct"]
# l6_pts is computed inside _get_float_pressure_signals based on pressure tiers
```

### Layer 7: Far-OTM Sweep Detector
```python
# Source: _get_far_otm_sweeps(days_back=3)
# Looks for sweeps with high volume-to-open-interest ratio (unusual urgency)
voi = float(sweep.get("vol_oi") or 0)
pts = 2.0 if voi >= 10 else 1.5 if voi >= 7 else 1.0
scores[ticker]["pts"]["far_otm_sweep"] = pts
```

### Layer 8: Sector Theme Correlation
```python
# Source: _get_sector_heat(days_back=2)
# hot_sectors → sympathy_plays: tickers in the same sector as the leading mover
for hs in sector_heat.get("hot_sectors", []):
    heat = hs["heat_score"]
    for tk in hs.get("sympathy_plays", []):
        pts = 1.5 if heat >= 3 else 1.0 if heat >= 2 else 0.5
        scores[tk]["pts"]["sector_sympathy"] = max(existing, pts)
```

### Regime Multiplier (applied to sort/label, not raw pts)
```python
_regime_mult = {
    "full_exposure":   1.00,
    "normal_exposure": 1.00,
    "reduce_exposure": 0.85,
    "sit_out":         0.70,
}.get(regime_recommendation, 1.00)
adj_total = total_pts * _regime_mult
```

### Layer 10: Fragility / Crowding Penalty (modifier)
```python
# Source: _get_fragility_crowding_penalties() — penalizes names that have appeared
# repeatedly in the scan (crowding risk)
penalty = l10["penalty_pts"]   # negative float, e.g. -0.5 or -1.0
scores[tk]["pts"]["fragility_penalty"] = penalty
```

---

## 4. BYOK Implementation

**Location:** `main.py` lines 2170–2200 + routes at lines 67,063+ and 68,525+

### Key Collection
```
Auth header format:  Authorization: sub_<token>:<sk-openai_key>
Tier 2 subscribers only. Token must be active+paid in sm_subscribers.
Key SHA-256 must match stored hash (ask_openai_key_hash column).
```

### Encryption at Rest
```python
# main.py ~line 2172
# Keys encrypted with AES-128-CBC via Fernet symmetric encryption
from cryptography.fernet import Fernet as _Fernet
_BYOK_FERNET = _Fernet(os.environ.get("BYOK_MASTER_KEY", "").encode())

def _byok_encrypt(plaintext: str) -> str:
    return _BYOK_FERNET.encrypt(plaintext.encode()).decode()

def _byok_decrypt(token_enc: str) -> str:
    return _BYOK_FERNET.decrypt(token_enc.encode()).decode()
```

### Storage Schema
```sql
-- Columns added to sm_subscribers table at startup
ALTER TABLE sm_subscribers ADD COLUMN IF NOT EXISTS openai_key_enc TEXT;
ALTER TABLE sm_subscribers ADD COLUMN IF NOT EXISTS polygon_key_enc TEXT;
ALTER TABLE sm_subscribers ADD COLUMN IF NOT EXISTS anthropic_key_enc TEXT;
ALTER TABLE sm_subscribers ADD COLUMN IF NOT EXISTS ask_openai_key_hash TEXT;
ALTER TABLE sm_subscribers ADD COLUMN IF NOT EXISTS ask_daily_limit INT DEFAULT 10;
```

### Runtime Use
```python
# At request time, key is decrypted and passed directly to OpenAI SDK
if byok_openai_key:
    client = OpenAI(api_key=byok_openai_key)
# otherwise platform key is used
```

### Key Management Routes
- `POST /stock-api/user/byok-key` — subscriber saves their key (encrypted before DB write)
- `DELETE /stock-api/user/byok-key` — clears all three encrypted key columns
- `GET /stock-api/user/byok-status` — returns which key types are stored (no plaintext returned)

### Master Key Rotation
Master key (`BYOK_MASTER_KEY`) is a Replit Secret. Rotation requires:
1. Re-encrypting all stored keys with the new master key
2. Updating the Replit Secret — no grace period

---

## 5. Stripe Billing + Affiliate Infrastructure

### Stripe Integration Status: **Partially wired / manual subscription management**

The stock scanner does **not** have a direct `import stripe` in `main.py`. Subscription state is managed via the `sm_subscribers` PostgreSQL table with `active` (boolean) and `paid` (boolean) columns. Stripe checkout and webhook handling for the stock scanner product appear to be handled externally or via a separate process not in scope of this export.

**What IS wired:**
```python
# main.py line 53,797
@app.route("/stock-api/check-subscription", methods=["POST"])
def check_subscription():
    """Check if an email has active Pro subscription (or is admin)."""
    # Reads: SELECT active, paid FROM sm_subscribers WHERE LOWER(email) = %s
```

**sm_subscribers table columns (inferred from code):**
- `token` — unique subscriber token used for API auth
- `email` — subscriber email
- `active` — boolean: account active
- `paid` — boolean: subscription current
- `ask_daily_limit` — per-subscriber AI query limit
- `openai_key_enc`, `polygon_key_enc`, `anthropic_key_enc` — BYOK encrypted keys
- `ask_openai_key_hash` — SHA-256 of OpenAI key for fast validation

**Affiliate:** No affiliate/referral/commission code found in the stock scanner export. The NCLEX prep artifact (`artifacts/nclex-prep/`) has a Stripe Connect affiliate system — that is a separate product.

**Buyer note:** A new owner would need to wire a Stripe subscription checkout flow that writes rows into `sm_subscribers`. The check-subscription and BYOK endpoints are ready to consume it.

---

## 6. Data Source Dependencies

| Source | Key/Auth | Used For | License / Transfer Notes |
|---|---|---|---|
| **Polygon.io** | `POLYGON_API_KEY` (env secret) | Full-market daily RVOL scan (11k+ tickers), options chains, grouped daily bars | Paid API — key is NOT transferable; buyer needs own account. Usage: ~5 API calls/scan for the grouped-daily endpoint. |
| **Tradier** | `TRADIER_API_TOKEN_2` (env secret) | Options quotes, options order routing | Paid API — key not transferable; Tradier requires a brokerage account. |
| **yfinance** | None (public) | Supplementary price/fundamental data | Public, no key needed. Rate-limited (~3 req/sec via built-in rate limiter). No official license; scraping ToS applies. |
| **FINRA ATS** | None (public) | Dark pool / off-exchange volume % | Public regulatory data. No API key. |
| **FRED** | None (public) | Macro indicators (rates, inflation, etc.) via `fred_macro.py` | Public. No key required. |
| **Reddit** | None (public) | WSB sentiment via `reddit_sentiment.py` | Public API. No key. Reddit ToS applies. |
| **Finviz** | None (web scrape) | Short interest data, market screener | Web scraping. No official API. ToS prohibits scraping — transfer risk: Finviz may block by IP. |
| **Congress.gov** | None (public) | Congressional trading disclosures | Public government data. |
| **OpenAI** | BYOK or platform key | AI analysis layer in scanner | Platform key is not transferable. BYOK model (subscriber supplies own key) is transferable by design. |
| **Anthropic** | BYOK or platform key | Secondary AI model | Same as OpenAI. |

**Transfer summary:** Polygon and Tradier keys are non-transferable — buyer needs their own accounts. yfinance, FINRA, FRED, Reddit, Congress data are freely accessible. Finviz web scraping is legally ambiguous.

---

## 7. Tests, Docs, and Setup

### Automated Tests
**No pytest/unittest test suite exists for the stock scanner.** Testing is done through:

1. **Backtest scripts** (`backtest.py`, `backtest_*.py` — 14 scripts): Historical walk-forward validation of each signal. These are run manually, not CI-automated.
2. **`test_terminal_api.py`** (380 lines): Manual API smoke-test script for the terminal API endpoints.
3. **`patterns/zero_dte_sweep.py`**: Contains an inline `if __name__ == "__main__"` test harness that runs a 5-scan validation with live data (added 2026-07-26).
4. **AIEM verification scripts** (`verify_*.py`): These belong to the institutional engine, not the stock scanner, and are excluded from this export.

### Documentation
- `docs/verification/zero_dte_sweep-FINAL.md` — verification disposition for the 0DTE scanner module (included in export)
- No formal API documentation or OpenAPI spec exists
- No setup guide exists beyond the Replit workflow configuration

### Setup Instructions (reconstructed)
```bash
# 1. Required env vars / secrets:
POLYGON_API_KEY=<polygon.io paid key>
TRADIER_API_TOKEN_2=<tradier brokerage key>
BYOK_MASTER_KEY=<fernet key: base64url-encoded 32 bytes>
DATABASE_URL=<postgresql://...>

# 2. Python dependencies (see requirements.txt if present, or pip install):
pip install flask flask-cors psycopg2-binary apscheduler cryptography \
            openai anthropic xgboost pandas numpy scipy yfinance \
            requests beautifulsoup4

# 3. Database: PostgreSQL required. Schema is auto-bootstrapped on startup
# via _run_schema_bootstrap() (deferred init in main.py).

# 4. Start:
python main.py   # binds to $PORT (default 5055)
```

---

## 8. Line Count / File Count Summary

| Category | Files | Lines |
|---|---|---|
| **Backend Python (stock scanner)** | **149** | **118,330** |
| — `main.py` (monolith) | 1 | 70,851 |
| — All other `.py` files | 148 | 47,479 |
| **`patterns/` (0DTE scanner)** | **2** | **537** |
| **Frontend (React/TS)** | **77** | **30,574** |
| **Total in this export** | **228** | **149,441** |
| | | |
| Excluded: `aiem_*.py` | 108 | 76,933 |
| Excluded: `ase_*/verify_*/etc.` | 44 | 27,980 |

**Last commit:** 2026-07-26  
**Commit hash:** `e5eb9f9043d7f88c43424d2c774ca35ae85c35e9`  
**Commit message:** "Update record to confirm decision on minimum history value"

Note: because `main.py` is a monolith, the 70,851-line figure includes AIEM institutional engine endpoints that are interleaved with stock scanner endpoints. A rough estimate is that ~40-50% of `main.py` is stock scanner code and ~50-60% is the institutional AIEM layer. A clean separation has not been performed.

---

*Prepared for external technical review. No AIEM institutional engine code, no options assignment strategy engine, and no verification infrastructure is included in this package.*

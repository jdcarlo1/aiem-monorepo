# NCLEX AI — Security Status

Generated: 2026-07-27

## Authentication & Authorisation

| Mechanism | Status | Notes |
|-----------|--------|-------|
| Clerk JWT verification | ✅ Active | `clerkMiddleware` validates all requests |
| Clerk proxy (custom domain) | ✅ Active | `/api/__clerk` tunnels FAPI in production |
| API routes — auth guards | ⚠️ Public | No `requireAuth()` guards on question/session routes by design (anonymous access intended) |
| Admin endpoints | ✅ Protected | `X-Admin-Secret` header checked against `ADMIN_TOKEN` env var |
| Stripe webhook signature | ✅ Verified | Raw buffer passed to stripe-replit-sync processWebhook |

## Secrets Management

| Secret | Storage | Notes |
|--------|---------|-------|
| `STRIPE_SECRET_KEY` | Replit Secrets | Never logged, never exposed to frontend |
| `CLERK_SECRET_KEY` | Replit Secrets | Backend only |
| `CLERK_PUBLISHABLE_KEY` | Replit Secrets | Safe to expose (public key) |
| `VITE_CLERK_PUBLISHABLE_KEY` | Replit Secrets | Bundled into frontend at build time |
| `DATABASE_URL` | Replit Secrets | Connection string includes credentials |
| `ADMIN_TOKEN` | Replit Secrets | Protects affiliate admin endpoints |
| `AI_INTEGRATIONS_ANTHROPIC_API_KEY` | Replit Secrets | Used server-side only |

No secrets appear in source code. All secrets are in `.env` / Replit Secrets.

## CORS Configuration

| Setting | Value |
|---------|-------|
| Origin | `true` (any origin) — Express `cors({ credentials: true, origin: true })` |
| Credentials | Allowed |

⚠️ CORS is currently open. This is intentional for a multi-domain setup but
should be locked to `nclexai.org` for hardened production.

## Stripe Security

| Control | Status |
|---------|--------|
| Webhook signature verification | ✅ stripe-replit-sync validates signature |
| Raw body preservation | ✅ Webhook route registered before express.json() |
| Idempotency | ⚠️ Partial — no idempotency keys on transfer creation |
| Affiliate payout guard | ✅ Checks `payouts_enabled` before transfer |

## Input Validation

| Layer | Status |
|-------|--------|
| Request body types | TypeScript types only (no runtime Zod validation on most routes) |
| SQL injection | ✅ Not possible — Drizzle ORM uses parameterised queries |
| Question ID parsing | ✅ `parseInt` + NaN check |
| Admin token comparison | ✅ Direct string equality |

⚠️ Runtime Zod validation is generated in `@workspace/api-zod` but not wired
into the API routes — it is used by the frontend via the client library only.

## Logging & Data Exposure

| Control | Status |
|---------|--------|
| Auth header redaction | ✅ Pino redacts `req.headers.authorization` and `cookie` |
| PII in logs | ⚠️ Session IDs and customer emails appear in info-level logs |
| Error detail exposure | ⚠️ Some routes return raw error messages to the client |

## Known Gaps (for audit)

1. **No rate limiting** — the API has no rate limiting on answer submission or
   checkout creation. A session can spam answers without restriction.

2. **CORS open** — `origin: true` accepts requests from any domain.

3. **No runtime request validation** — the Zod schemas in `@workspace/api-zod`
   are not applied server-side. Malformed request bodies reach route handlers
   as-is.

4. **Admin routes not Clerk-gated** — admin endpoints use a shared static token
   rather than a Clerk role/claim. Token rotation requires a Replit Secret change.

5. **TypeScript errors** — 19 API server and 16 frontend type errors exist
   (detailed in ARCHITECTURE.md). These do not affect runtime behaviour but
   indicate type-unsafe code paths.

6. **No CSP header** — the SPA HTML has no Content-Security-Policy header.

## Dependency Audit

No automated dependency audit has been run. Recommended:
```bash
pnpm audit
```

Key dependencies to monitor:
- `stripe` — ensure latest API version for security patches
- `@clerk/express` — auth library; keep current
- `express` — v5.x (current)
- `drizzle-orm` — ORM; keep current

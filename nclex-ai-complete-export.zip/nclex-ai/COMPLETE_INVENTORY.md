# NCLEX AI — Complete File Inventory

Generated: 2026-07-27  |  Git: 05a8808d10a8cbfe5cc206277dbb8bb7c72c5c9e

## artifacts/api-server/src/

| File | Purpose |
|------|---------|
| `app.ts` | Express app factory — health check, Stripe webhook (raw body), Clerk proxy, middleware, router |
| `index.ts` | Entry point — server listen, Stripe init (schema migration + webhook registration) |
| `stripeClient.ts` | Stripe credential resolution (Replit integration or env var), client factory, StripeSync |
| `webhookHandlers.ts` | Processes all Stripe webhook events: checkout, invoice renewal, subscription cancel, affiliate payouts |
| `lib/logger.ts` | Pino logger (pretty in dev, JSON in prod, redacts auth headers) |
| `middlewares/clerkProxyMiddleware.ts` | Tunnels Clerk Frontend API requests through `/api/__clerk` for custom domain auth |
| `routes/index.ts` | Central router — mounts all sub-routers |
| `routes/health.ts` | GET /api/healthz — Zod-validated health response |
| `routes/questions.ts` | GET /api/questions, GET /api/questions/:id — question bank access |
| `routes/session.ts` | Session status, answer submission, legacy checkout/cancel stubs |
| `routes/adaptive.ts` | Adaptive engine — GET /api/adaptive/next (weighted category selection), /adaptive/performance |
| `routes/stripe.ts` | Stripe checkout (monthly + lifetime), restore-access, billing portal, admin activate |
| `routes/affiliates.ts` | Admin CRUD for affiliates + Stripe Connect onboarding |
| `routes/analyze.ts` | POST /api/analyze — Claude swing-trade stock analysis |
| `routes/catalyst.ts` | POST /api/catalyst — Claude options-flow catalyst analysis |
| `routes/morning-brief.ts` | GET /api/morning-brief — cached daily AI market brief |

## artifacts/nclex-prep/src/

| File | Purpose |
|------|---------|
| `main.tsx` | React root mount |
| `App.tsx` | ClerkProvider, React Query, wouter router, Clerk appearance theme |
| `index.css` | Tailwind CSS v4 theme + CSS custom properties (light/dark) |
| `components/EkgDisplay.tsx` | Real EKG paper simulation (SVG path generator, 1000px strip, 10 waveform variants) |
| `pages/landing.tsx` | Full marketing landing page: hero, feature demos, NGN demo, Bowtie demo, pricing, testimonials |
| `pages/quiz.tsx` | Primary adaptive quiz: SingleChoice, MultipleChoice, OrderedChoice, EKG display, paywall gate |
| `pages/study-quiz.tsx` | Study mode: category/question-type filter, same question components, no paywall |
| `pages/paywall.tsx` | Subscription page: monthly/lifetime plan, Stripe checkout, restore-access, referral code input |
| `pages/home.tsx` | Authenticated home: testimonials, comparison table, session status, sign-out |
| `pages/nursing-school.tsx` | 48 nursing school categories with targeted question banks |
| `pages/interview-prep.tsx` | 20 nursing interview prep questions |
| `pages/admin-affiliates.tsx` | Admin UI: affiliate list, create, refresh onboarding link, Stripe status badges |
| `pages/subscribe-success.tsx` | Post-checkout success confirmation page |
| `pages/sign-in.tsx` | Clerk SignIn component with branded wrapper |
| `pages/sign-up.tsx` | Clerk SignUp component with branded wrapper |
| `pages/flyer.tsx` | Printable A5 flyer with QR code (qrcode.react) |
| `pages/not-found.tsx` | 404 page |
| `hooks/useSessionId.ts` | Returns Clerk user ID if authenticated, else localStorage UUID |
| `hooks/useAutoRestore.ts` | Auto-restores Stripe subscription on mount using stored payment email |
| `hooks/use-toast.ts` | shadcn/ui toast hook |
| `hooks/use-mobile.tsx` | Breakpoint hook |
| `lib/session.ts` | localStorage helpers: getSessionId, getPaymentEmail, setPaymentEmail |
| `lib/utils.ts` | `cn()` (clsx + tailwind-merge) |
| `components/ui/` | 36 shadcn/ui components (accordion through tooltip) |

## lib/api-client-react/src/

| File | Purpose |
|------|---------|
| `index.ts` | Re-exports generated hooks and custom fetch |
| `custom-fetch.ts` | Fetch wrapper: ApiError class, ResponseParseError, JSON/BOM handling |
| `generated/api.ts` | Orval-generated React Query hooks for all API endpoints |
| `generated/api.schemas.ts` | Orval-generated TypeScript interfaces for all request/response types |

## lib/api-zod/src/

| File | Purpose |
|------|---------|
| `index.ts` | Re-exports generated validators |
| `generated/api.ts` | Orval-generated Zod schemas for all API endpoints |
| `generated/types/*.ts` | Individual Zod type files (AnswerInput, AnswerResult, SessionStatus, etc.) |

## lib/db/src/

| File | Purpose |
|------|---------|
| `index.ts` | Pool + Drizzle DB instance; re-exports all schema |
| `schema/questions.ts` | `questionsTable` schema + Zod insert type |
| `schema/sessions.ts` | `sessionsTable` + `answersTable` schemas + Zod types |
| `schema/affiliates.ts` | `affiliatesTable` schema |
| `schema/index.ts` | Re-exports all schema tables |

## lib/api-spec/

| File | Purpose |
|------|---------|
| `openapi.yaml` | OpenAPI 3.1 spec — canonical API contract |
| `aiem-terminal-openapi.yaml` | AIEM institutional terminal API spec |
| `orval.config.ts` | Orval codegen config — generates both react-query and zod targets |

## Configuration Files

| File | Purpose |
|------|---------|
| `package.json` | Workspace root scripts (build, typecheck) |
| `pnpm-workspace.yaml` | pnpm workspace packages + catalog dependencies |
| `tsconfig.base.json` | Shared TS options (ES2022, bundler module resolution, strict) |
| `tsconfig.json` | Project references (db, api-client-react, api-zod composites) |
| `artifacts/api-server/tsconfig.json` | API server TS config (references db + api-zod) |
| `artifacts/api-server/build.mjs` | esbuild config (ESM output, pino plugin, source maps) |
| `artifacts/nclex-prep/tsconfig.json` | Frontend TS config |
| `artifacts/nclex-prep/vite.config.ts` | Vite config (Tailwind, path aliases, port from env) |
| `artifacts/nclex-prep/components.json` | shadcn/ui component registry config |
| `artifacts/nclex-prep/index.html` | HTML entry point (Google Analytics, meta tags, fonts) |
| `lib/db/drizzle.config.ts` | Drizzle Kit config (tablesFilter: sessions, affiliates) |
| `scripts/post-merge.sh` | Post-merge script: pnpm install + drizzle push |
| `.env.example` | Environment variable template (all secrets replaced with placeholders) |

## Production Build Outputs

| Output | Size | Notes |
|--------|------|-------|
| `artifacts/api-server/dist/index.mjs` | 4.1 MB | esbuild single bundle |
| `artifacts/nclex-prep/dist/public/assets/index-*.js` | 647 KB | Vite production bundle |
| `artifacts/nclex-prep/dist/public/assets/index-*.css` | 138 KB | Tailwind CSS output |

## Test Coverage

No automated test suite currently exists for the NCLEX project.
The following manual verification is performed:
- Build passes (`pnpm --filter @workspace/api-server run build` — ✓)
- Frontend build passes (`pnpm --filter @workspace/nclex-prep run build` — ✓)
- TypeScript strict mode (pre-existing errors documented in ARCHITECTURE.md)
- Stripe webhook verified end-to-end (live checkout tested)
- Adaptive engine verified via manual quiz sessions

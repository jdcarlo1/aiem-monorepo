# NCLEX AI — Architecture

## Overview

NCLEX AI is a full-stack web application for NCLEX nursing exam preparation.
It uses an AI-powered adaptive engine to personalise practice sessions,
supports multiple question types (including Next Generation NCLEX formats),
and monetises through Stripe subscriptions with an affiliate referral system.

**Production URL:** https://nclexai.org

---

## Monorepo Structure

```
workspace/                     ← pnpm workspace root
├── artifacts/
│   ├── api-server/            ← Express 5 API (Node.js 24)
│   └── nclex-prep/            ← React 18 + Vite 7 SPA frontend
├── lib/
│   ├── api-client-react/      ← Generated React Query hooks (Orval)
│   ├── api-spec/              ← OpenAPI 3.1 spec + Orval codegen config
│   ├── api-zod/               ← Generated Zod validators (Orval)
│   └── db/                    ← Drizzle ORM schema + connection pool
├── scripts/
│   └── post-merge.sh          ← Runs pnpm install + drizzle push after merges
├── package.json               ← Workspace root scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json         ← Shared TS compiler options
└── tsconfig.json              ← Project references (lib composites)
```

---

## Artifact Services

| Service          | Port  | Path   | Stack                  |
|------------------|-------|--------|------------------------|
| API Server       | 8080  | /api   | Express 5, Node 24     |
| NCLEX Prep (SPA) | 24069 | /      | React 18, Vite 7       |

Both services are registered in `artifact.toml` files under each artifact
directory. The API server builds to `dist/index.mjs` via esbuild; the SPA
builds to `dist/public/` via Vite and is served as a static site in production.

---

## Technology Stack

### Backend — `artifacts/api-server`
| Layer            | Technology                                 |
|------------------|--------------------------------------------|
| Runtime          | Node.js 24 (ESM)                           |
| Framework        | Express 5                                  |
| ORM              | Drizzle ORM (drizzle-orm/pg-core)          |
| Database         | PostgreSQL 16                              |
| Auth middleware  | @clerk/express (Clerk JWT verification)    |
| Payments         | stripe SDK + stripe-replit-sync            |
| Affiliate payouts| Stripe Connect Express                     |
| AI               | @anthropic-ai/sdk (Claude Haiku)           |
| Logging          | pino + pino-http                           |
| Build            | esbuild (single ESM bundle)                |
| Validation       | Zod v4 (via @workspace/api-zod)            |

### Frontend — `artifacts/nclex-prep`
| Layer            | Technology                                 |
|------------------|--------------------------------------------|
| Framework        | React 18                                   |
| Build tool       | Vite 7                                     |
| Styling          | Tailwind CSS v4 + tailwindcss/typography   |
| Component lib    | shadcn/ui (Radix UI primitives)            |
| Auth             | @clerk/react (ClerkProvider + hooks)       |
| Routing          | wouter                                     |
| Data fetching    | @tanstack/react-query v5                   |
| API client       | @workspace/api-client-react (Orval-gen)    |
| Animations       | framer-motion                              |
| EKG component    | Custom SVG path generator (EkgDisplay.tsx) |

### Shared Libraries
| Package                       | Purpose                                    |
|-------------------------------|--------------------------------------------|
| @workspace/db                 | Drizzle schema, pool, typed exports        |
| @workspace/api-client-react   | Generated React Query hooks                |
| @workspace/api-zod            | Generated Zod validators                   |
| @workspace/api-spec           | OpenAPI spec + Orval codegen config        |

---

## API Routes

All routes are prefixed `/api`.

### Health
| Method | Path          | Auth     | Description        |
|--------|---------------|----------|--------------------|
| GET    | /healthz      | None     | Liveness probe     |

### Questions
| Method | Path              | Auth     | Description                     |
|--------|-------------------|----------|---------------------------------|
| GET    | /questions        | None     | List all questions (summaries)  |
| GET    | /questions/:id    | None     | Get full question detail        |

### Session & Adaptive Engine
| Method | Path                      | Auth     | Description                         |
|--------|---------------------------|----------|-------------------------------------|
| GET    | /session/status           | None     | Get session status + subscription   |
| POST   | /session/answer           | None     | Submit answer; returns result+expl. |
| GET    | /adaptive/next            | None     | Get next question (adaptive engine) |
| GET    | /adaptive/performance     | None     | Get per-category accuracy stats     |
| POST   | /subscription/checkout    | None     | Legacy checkout stub                |
| POST   | /subscription/cancel      | None     | Cancel subscription                 |

### Stripe (Payments & Subscriptions)
| Method | Path                          | Auth        | Description                               |
|--------|-------------------------------|-------------|-------------------------------------------|
| POST   | /stripe/checkout              | None        | Create Stripe checkout session            |
| POST   | /stripe/webhook               | Stripe-sig  | Receive Stripe events (raw body)          |
| POST   | /stripe/restore-access        | None        | Restore subscription by email             |
| POST   | /stripe/manage                | None        | Create Stripe billing portal session      |
| POST   | /admin/activate-sessions      | Admin token | Manually activate a session               |

### Affiliates (Admin)
| Method | Path                                  | Admin-token | Description                          |
|--------|---------------------------------------|-------------|--------------------------------------|
| GET    | /admin/affiliates                     | ✓           | List all affiliates + Stripe status  |
| POST   | /admin/affiliates                     | ✓           | Create affiliate + Stripe Connect    |
| POST   | /admin/affiliates/:code/refresh-link  | ✓           | Regenerate onboarding link           |
| DELETE | /admin/affiliates/:code               | ✓           | Delete affiliate                     |

### AI
| Method | Path               | Auth     | Description                        |
|--------|--------------------|----------|------------------------------------|
| POST   | /analyze           | None     | Claude swing-trade stock analysis  |
| POST   | /catalyst          | None     | Claude options-flow catalyst       |
| GET    | /morning-brief     | None     | Daily AI market brief (cached)     |

---

## Adaptive Engine

File: `artifacts/api-server/src/routes/adaptive.ts`

The adaptive engine (`computeAdaptiveNext`) implements a weighted random
selection algorithm:

1. **Load answered history** — all answer rows for the session
2. **Build category accuracy map** — per-category correct/total
3. **Orientation mode** — first 2 questions always draw from Cardiac single-choice
4. **Score unanswered categories** — weight = (1 − accuracy)² + 0.05 floor
5. **Weighted random category pick** — weaker categories appear more often
6. **Random question from category pool**

The 0.05 floor ensures even fully-mastered categories occasionally appear,
preventing tunnel-vision on weak areas.

---

## Authentication Flow (Clerk)

1. **Anonymous** — browser generates a UUID session ID (stored in localStorage)
2. **Sign-in** — ClerkProvider initialises; `useSessionId()` returns Clerk user ID
   instead of localStorage UUID once loaded
3. **JWT verification** — `clerkMiddleware` in Express validates Clerk JWTs on
   every request; currently all API routes are public (no `requireAuth` guards
   in place — Clerk is used for identity, not access control on the API)
4. **Clerk proxy** — `clerkProxyMiddleware` tunnels Clerk Frontend API requests
   through `/api/__clerk` in production to support custom domains without CNAME

---

## Payment Flow (Stripe)

### Checkout
1. Frontend POSTs to `/api/stripe/checkout` with `{sessionId, plan, referralCode?}`
2. API finds or creates a Stripe Customer for the session
3. Validates referral code against `affiliates` table; stores on session
4. Creates a Stripe Checkout Session (subscription or one-time payment)
5. Returns redirect URL; browser navigates to Stripe-hosted checkout page

### Webhook Processing (`/api/stripe/webhook`)
Raw body is required — route is registered **before** `express.json()`.

| Event                              | Action                                              |
|------------------------------------|-----------------------------------------------------|
| `checkout.session.completed`       | Unlock session (`is_subscribed = true`)             |
| `checkout.session.completed`       | Affiliate transfer for lifetime purchases           |
| `invoice.payment_succeeded`        | Affiliate transfer for monthly renewals             |
| `customer.subscription.deleted`    | Revoke access (`is_subscribed = false`)             |

### Affiliate Commission
- Express Connect accounts created via `stripe.accounts.create({ type: 'express' })`
- Onboarding link sent to affiliate via admin UI
- Commission transferred via `stripe.transfers.create` after payout eligibility check
- Lifetime: paid once at `checkout.session.completed`
- Monthly: paid on every `invoice.payment_succeeded`

### Access Restore
POST `/api/stripe/restore-access` — looks up Stripe customers by email,
checks for active subscriptions, and re-activates the session.

---

## Question Bank

| Metric               | Value                                     |
|----------------------|-------------------------------------------|
| Total questions      | 1,508                                     |
| Categories           | 57                                        |
| Single-choice        | 1,415 (93.8%)                             |
| Multiple-choice (SATA) | 50 (3.3%)                               |
| Ordered (drag-drop)  | 43 (2.9%)                                 |
| NGN Clinical Judgment | 53 questions                             |
| Largest category     | NGN - Clinical Judgment (53)              |

Options are stored as JSONB. Old questions use `{A: "text"}` objects;
new questions use `[{letter, text}]` arrays. The API normalises both formats
on read (see `routes/questions.ts`).

---

## Frontend Pages

| Route                   | Component           | Description                              |
|-------------------------|---------------------|------------------------------------------|
| `/`                     | Landing             | Marketing landing page with demos        |
| `/quiz`                 | Quiz                | Adaptive quiz (API-driven, free gate)    |
| `/study`                | StudyQuiz           | Study mode (all categories, no gate)     |
| `/nursing-school`       | NursingSchool       | Targeted nursing school question banks   |
| `/paywall`              | Paywall             | Subscription page (monthly/lifetime)     |
| `/subscribe-success`    | SubscribeSuccess    | Post-checkout confirmation               |
| `/interview-prep`       | InterviewPrep       | 20 nursing job interview questions       |
| `/home`                 | Home                | Dashboard / marketing (authenticated)    |
| `/flyer`                | Flyer               | Printable A5 marketing flyer + QR code   |
| `/admin/affiliates`     | AdminAffiliates     | Affiliate management (admin-token gated) |
| `/sign-in`              | SignInPage           | Clerk sign-in                            |
| `/sign-up`              | SignUpPage           | Clerk sign-up                            |

---

## Codegen Pipeline

OpenAPI spec: `lib/api-spec/openapi.yaml`
Config: `lib/api-spec/orval.config.ts`
Command: `pnpm --filter @workspace/api-spec run codegen`

Orval generates two output targets from the same OpenAPI spec:
- **react-query** → `lib/api-client-react/src/generated/` (hooks + fetch)
- **zod** → `lib/api-zod/src/generated/` (validators for server-side validation)

Never edit generated files manually.

---

## Deployment

Platform: Replit Reserved VM (GCE)

| Environment | URL                                      |
|-------------|------------------------------------------|
| Production  | https://nclexai.org                      |
| Dev preview | https://*.replit.dev (path-routed)       |

### Build Commands
```bash
# Frontend
pnpm --filter @workspace/nclex-prep run build   # → artifacts/nclex-prep/dist/public/

# API server
pnpm --filter @workspace/api-server run build   # → artifacts/api-server/dist/index.mjs
```

### Startup Sequence (production)
1. `node --enable-source-maps artifacts/api-server/dist/index.mjs`
2. `GET /api/healthz` → 200 (Replit promote-phase health check)
3. `initStripe()` — runs DB schema migration, registers webhook, backfills data
4. Static SPA served from `artifacts/nclex-prep/dist/public/` by Replit's CDN

---

## Known TypeScript Errors

TypeScript strict mode is configured but the following pre-existing errors
exist in the working codebase (does not affect runtime — esbuild transpiles
without type checking):

**API Server (19 errors):**
- `@workspace/db` exports `db` and schema tables; tsbuild info is stale
  → fix by running `pnpm run typecheck:libs` first to rebuild composite packages
- `stripe.checkout.sessions.search` not in Stripe SDK type declarations
- Several `unknown` type narrowing issues in webhook and Stripe client

**Frontend (16 errors):**
- `queryKey` missing in `useQuery` options (react-query v5 API difference)
- `onClick={load}` signature mismatch in `admin-affiliates.tsx`
- Several `string | undefined` strict-null assignments in study/interview pages

These are all fixable in a dedicated cleanup pass.

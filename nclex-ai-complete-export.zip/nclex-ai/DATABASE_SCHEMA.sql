-- ============================================================
-- NCLEX AI — Complete Database Schema
-- Generated: 2026-07-27
-- Engine: PostgreSQL 16
-- ORM: Drizzle ORM (drizzle-orm/pg-core)
-- ============================================================

-- Drop order respects FK dependencies (none declared; order is alphabetical)
DROP TABLE IF EXISTS answers;
DROP TABLE IF EXISTS affiliates;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS questions;

-- ── questions ────────────────────────────────────────────────────────────────
-- Central question bank. Stores all NCLEX practice questions.
-- question_type: 'single' | 'multiple' | 'ordered'
--   single   — standard single-best-answer (A/B/C/D/E)
--   multiple — Select All That Apply (SATA); correct_letter is comma-separated
--   ordered  — drag-and-drop ordering; correct_letter is ordered CSV
-- options: JSONB array of {letter: string, text: string} objects
--   Old questions stored {A: "text", B: "text"} plain-object format;
--   the API normalises both shapes to the array format on read.

CREATE TABLE questions (
  id               SERIAL PRIMARY KEY,
  question_number  INTEGER NOT NULL,
  category         TEXT    NOT NULL,
  text             TEXT    NOT NULL,
  options          JSONB   NOT NULL,          -- [{letter, text}, …]
  correct_letter   TEXT    NOT NULL,          -- "A" | "A,C" | "B,D,E"
  explanation      TEXT    NOT NULL,
  question_type    TEXT    NOT NULL DEFAULT 'single',
  image_url        TEXT,                      -- optional image asset URL
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── sessions ─────────────────────────────────────────────────────────────────
-- One row per anonymous browser session (UUID stored in localStorage).
-- Clerk-authenticated users use their Clerk user ID as session_id.
-- Free limit: 10 questions (FREE_LIMIT constant in routes/session.ts).

CREATE TABLE sessions (
  id                      SERIAL PRIMARY KEY,
  session_id              TEXT        NOT NULL UNIQUE,
  questions_answered      INTEGER     NOT NULL DEFAULT 0,
  is_subscribed           BOOLEAN     NOT NULL DEFAULT FALSE,
  subscription_end_date   TIMESTAMPTZ,        -- NULL = no fixed expiry (lifetime)
  email                   TEXT,               -- stored when user enters email
  stripe_customer_id      TEXT,               -- cus_xxx
  stripe_subscription_id  TEXT,               -- sub_xxx (NULL for lifetime)
  referral_code           TEXT,               -- affiliate referral code used at checkout
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── answers ──────────────────────────────────────────────────────────────────
-- Per-question answer log. Drives the adaptive engine and performance stats.
-- session_id references sessions.session_id (soft FK — no DB constraint).

CREATE TABLE answers (
  id              SERIAL PRIMARY KEY,
  session_id      TEXT    NOT NULL,
  question_id     INTEGER NOT NULL,           -- FK → questions.id (soft)
  selected_letter TEXT    NOT NULL,           -- what the user chose
  correct         BOOLEAN NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── affiliates ───────────────────────────────────────────────────────────────
-- Affiliate / referral partner records.
-- Stripe Connect Express accounts receive automatic commission transfers.
-- commission_pct: integer percentage (default 50 = 50%).

CREATE TABLE affiliates (
  id                SERIAL PRIMARY KEY,
  code              TEXT    NOT NULL UNIQUE,  -- e.g. "JOHN2025" (uppercase)
  name              TEXT    NOT NULL,         -- display name
  stripe_connect_id TEXT,                     -- acct_xxx (NULL until onboarded)
  commission_pct    INTEGER NOT NULL DEFAULT 50,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Stripe sync schema (managed by stripe-replit-sync) ───────────────────────
-- The stripe-replit-sync package creates its own tables under the 'stripe'
-- schema during runMigrations(). Those tables are NOT part of this file;
-- they are managed entirely by the library. Run initStripe() on startup.

-- ── Indexes ──────────────────────────────────────────────────────────────────
-- (Primary keys and UNIQUE constraints already create indexes above)
-- Additional indexes for common query patterns:
CREATE INDEX IF NOT EXISTS idx_answers_session_id    ON answers(session_id);
CREATE INDEX IF NOT EXISTS idx_answers_question_id   ON answers(question_id);
CREATE INDEX IF NOT EXISTS idx_sessions_stripe_cust  ON sessions(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_sessions_referral     ON sessions(referral_code);
CREATE INDEX IF NOT EXISTS idx_questions_category    ON questions(category);
CREATE INDEX IF NOT EXISTS idx_questions_type        ON questions(question_type);

-- ── Live row counts (as of export date) ──────────────────────────────────────
-- questions: 1,508 rows across 57 categories
-- sessions:     46 rows
-- answers:      11 rows
-- affiliates:    0 rows (none enrolled yet)

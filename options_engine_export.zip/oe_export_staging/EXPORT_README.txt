FULL CODEBASE EXPORT — Independent Audit
Generated: 2026-08-01
Monorepo root: /home/runner/workspace

WHAT IS INCLUDED
- All .py, .sh, .sql, .json, .md, .txt, .yml, .ts, .tsx, .js, .css source files
- tools/ directory (all scripts)
- .github/workflows/ directory (all CI configs)
- git_log_14d.txt — full git log last 14 days (oneline + file list per commit)
- db_schema_7_tables.txt — column/index/constraint definitions for 7 audit tables
- canonical_hashes.json (see note below)

WHAT IS EXCLUDED (binary/cache, not relevant to code audit)
- *.pkl  — serialized ML model binaries and cache files
- *.parquet — columnar data cache files
- __pycache__/ directories
- *.pyc compiled bytecode
- aiem_all_modules.zip / stockscanner_full_export.zip (pre-existing archive artifacts)

NOTE ON canonical_hashes.json
No standalone canonical_hashes.json was found in tools/. Hash references are embedded
directly in tools/verified_run.sh (CANONICAL_SHA256 variable) and
tools/verify_chain.sh. Those files are included in full.

aiem_export.zip:  Full AIEM / stock-scanner-api repo (all source)
options_engine_export.zip: Options Engine focused subset (aiem_options_*, aiem_strat_engine/,
  aiem_portfolio_engine/, aiem_probability_engine/, payoff.py, scheduler + tools)

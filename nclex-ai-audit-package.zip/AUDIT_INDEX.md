# NCLEX AI — Audit Index

Generated: 2026-07-27  |  Git: 05a8808d10a8cbfe5cc206277dbb8bb7c72c5c9e

---

## 1. Frontend SPA

**Module:** Frontend SPA  
**File path(s):** `artifacts/nclex-prep/src/`  
**Purpose:** React 18 single-page application — quiz UI, paywall, admin affiliate panel, landing page.

**Called by:** Browser (end users)  
**Calls:**
- `/api/session/status` — checks subscription and answered count
- `/api/adaptive/next` — fetches next adaptive question
- `/api/questions/:id` — fetches full question detail
- `/api/session/answer` — submits answer
- `/api/stripe/checkout` — initiates Stripe checkout
- `/api/stripe/restore-access` — restores subscription by email
- `/api/stripe/verify-checkout` — verifies checkout after redirect
- `/api/stripe/manage` — billing portal
- `/api/admin/affiliates` (GET/POST/DELETE) — affiliate management
- `/api/admin/affiliates/:code/refresh-link` — refresh onboarding link

**API routes:** N/A (consumer only)  
**Database tables:** None directly; all via API  
**Authentication method:** Clerk (`@clerk/react`, ClerkProvider wraps app)  
**Authorization method:** `useSessionId()` returns Clerk user ID if authenticated, else localStorage UUID; admin page gated by `ADMIN_TOKEN` input in browser  
**Stripe interaction:** POSTs to `/api/stripe/checkout`, `/api/stripe/restore-access`, `/api/stripe/manage`, `/api/stripe/verify-checkout`  
**Clerk interaction:** `ClerkProvider` with custom appearance; `useUser()`, `useSignIn()`, `useSignUp()` from `@clerk/react`; `SignIn`/`SignUp` components on dedicated pages  
**Tests:** None  
**Known limitations:**
- Admin token is typed into the browser and stored only in React state — lost on page refresh, no persistence
- No CSRF protection on any API calls
- No input sanitization before sending to API
- `useAutoRestore` fires on every mount and calls restore-access silently — can generate noise in Stripe logs
- No loading skeleton on quiz page — first question fetch can produce a blank-white flash

**TODO/FIXME items:** None found in source (grep clean)

---

## 2. Backend API Server

**Module:** Backend API Server  
**File path(s):** `artifacts/api-server/src/`  
**Purpose:** Express 5 REST API — serves all NCLEX questions, sessions, payments, adaptive engine, affiliate management.

**Called by:** Frontend SPA; Stripe webhook delivery; external admin tooling  
**Calls:**
- PostgreSQL (via Drizzle ORM + `@workspace/db`)
- Stripe API (via `stripeClient.ts`)
- Anthropic Claude API (analyze, catalyst, morning-brief routes)
- Clerk JWKS endpoint (at middleware initialization)

**API routes:** See §§ 4–9 below  
**Database tables:** `questions`, `sessions`, `answers`, `affiliates`, `sm_subscribers` (raw SQL)  
**Authentication method:** `clerkMiddleware()` from `@clerk/express` validates JWTs on all requests; does NOT call `requireAuth()` on any route (all routes accept unauthenticated requests by design)  
**Authorization method:**
- Public routes: none required
- Admin routes: `X-Admin-Secret` header compared to `process.env.ADMIN_TOKEN`
- Stripe webhook: requires `stripe-signature` header; payload passed to stripe-replit-sync

**Stripe interaction:** Every route that touches payments instantiates a new `Stripe` client via `getUncachableStripeClient()` — no caching  
**Clerk interaction:** `clerkMiddleware()` applied globally; `clerkProxyMiddleware` tunnels requests to `/api/__clerk`  
**Tests:** None  
**Known limitations:**
- No rate limiting on any endpoint
- No request body validation (Zod validators generated but not wired server-side)
- 19 TypeScript errors (tsc strict) — see KNOWN_ISSUES.md
- `getUncachableStripeClient()` creates a new Stripe instance on every call (no singleton)
- Raw SQL used for `sm_subscribers` inserts/updates (no type safety, no ORM)

**TODO/FIXME items:** None found in project source files

---

## 3. Stripe Integration

**Module:** Stripe  
**File path(s):**
- `artifacts/api-server/src/stripeClient.ts`
- `artifacts/api-server/src/routes/stripe.ts`
- `artifacts/api-server/src/webhookHandlers.ts`
- `artifacts/api-server/src/index.ts`

**Purpose:** Checkout session creation (monthly subscription + lifetime one-time payment), webhook processing, access restore, billing portal, affiliate commission transfers via Stripe Connect Express.

**Called by:**
- `routes/stripe.ts` → `getUncachableStripeClient()`
- `routes/affiliates.ts` → `getUncachableStripeClient()`
- `webhookHandlers.ts` → `getStripeSync()`, `getUncachableStripeClient()`
- `index.ts` → `runMigrations()`, `getStripeSync()`, `stripeSync.findOrCreateManagedWebhook()`

**Calls:**
- `stripe.customers.create/update/list`
- `stripe.products.search/list`
- `stripe.prices.list`
- `stripe.checkout.sessions.create/retrieve/list/search`
- `stripe.billingPortal.sessions.create`
- `stripe.accounts.create/retrieve`
- `stripe.accountLinks.create`
- `stripe.transfers.create`
- `stripe-replit-sync`: `runMigrations()`, `getStripeSync()`, `StripeSync.processWebhook()`, `StripeSync.syncBackfill()`

**API routes:**
| Route | Method | Description |
|---|---|---|
| `/api/stripe/checkout` | POST | Create checkout session (monthly or lifetime) |
| `/api/stripe/verify-checkout` | POST | Verify payment after redirect back |
| `/api/stripe/restore-access` | POST | Restore subscription by email lookup |
| `/api/stripe/webhook` | POST | Receive Stripe events (raw body, `stripe-signature` required) |
| `/api/stripe/manage` | POST | Create billing portal session |
| `/api/stock-scanner/checkout` | POST | StockScanner product checkout |
| `/api/stock-scanner/manage` | POST | StockScanner billing portal |
| `/api/admin/seed-questions` | POST | Bulk question insert (admin-token gated) |
| `/api/admin/fix-sessions` | POST | Nullify subscriptions with no Stripe customer (admin-token gated) |
| `/api/admin/activate-sessions` | POST | Manually force-subscribe a session (admin-token gated) |

**Database tables written:**
- `sessions` — `isSubscribed`, `stripeCustomerId`, `stripeSubscriptionId`, `referralCode`
- `sm_subscribers` — raw SQL (no ORM type safety)

**Authentication method:** Webhook requires `stripe-signature` header (present, parsed by stripe-replit-sync); admin routes require `X-Admin-Secret`; checkout/restore require no auth  
**Authorization method:** Admin routes: `X-Admin-Secret === process.env.ADMIN_TOKEN`  
**Stripe interaction:** Central module; all Stripe API calls flow through here  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- `stripe.checkout.sessions.search` at `stripe.ts:191` causes TS2339 type error (not in Stripe SDK types at the pinned API version declared)
- `restore-access` uses `checkout.sessions.search` wrapped in `try/catch` with bare `catch (_) {}` — search failures are silently swallowed; the fallback `customers.list` always runs
- No idempotency keys on `stripe.transfers.create` — network retry could double-pay affiliates
- Lifetime payout triggered by `checkout.session.completed` with `mode === 'payment'`; monthly payout triggered by `invoice.payment_succeeded` — first monthly invoice also fires `invoice.payment_succeeded`, so first month IS paid out; this is correct behavior but requires verification per billing plan
- `stripe-replit-sync processWebhook` failure is non-fatal (warning only) — webhook events may be missed in the sync DB but session access is still granted
- `STRIPE_SECRET_KEY` preference logic: env var only used if it starts with `sk_live_`; test keys (`sk_test_`) fall through to Replit connector or the raw env var fallback — this is intentional but non-obvious

**TODO/FIXME items:** None found

---

## 4. Clerk Authentication

**Module:** Clerk Auth  
**File path(s):**
- `artifacts/api-server/src/app.ts` (middleware)
- `artifacts/api-server/src/middlewares/clerkProxyMiddleware.ts`
- `artifacts/nclex-prep/src/App.tsx`
- `artifacts/nclex-prep/src/hooks/useSessionId.ts`
- `artifacts/nclex-prep/src/pages/sign-in.tsx`
- `artifacts/nclex-prep/src/pages/sign-up.tsx`

**Purpose:** User identity via Clerk JWTs; custom-domain proxy for Clerk Frontend API; session ID resolution (Clerk user ID or anonymous localStorage UUID).

**Called by:** All frontend pages (ClerkProvider at root); all API requests (middleware on every route)  
**Calls:**
- Clerk JWKS endpoint (JWT verification)
- Clerk Frontend API (proxied via `/api/__clerk`)

**API routes:** `GET/POST /api/__clerk/*` (proxy, any method)  
**Database tables:** None (Clerk is identity-only; no Clerk data persisted to DB)  
**Authentication method:** ClerkProvider + `useUser()` frontend; `clerkMiddleware()` backend  
**Authorization method:** No `requireAuth()` guards — Clerk is used for identity only; all routes remain publicly accessible regardless of Clerk auth state  
**Stripe interaction:** None  
**Clerk interaction:** Full — this is the Clerk module  
**Tests:** None  
**Known limitations:**
- No `requireAuth()` middleware on any route — authenticated identity is available via `req.auth` but not enforced
- Proxy middleware is production-only; development hits Clerk directly
- `publishableKeyFromHost` is called on every request — if host header is spoofed, wrong publishable key is resolved (low impact, publishable key is public)
- No session invalidation on Stripe subscription cancellation — Clerk session remains active

**TODO/FIXME items:** None found

---

## 5. Sessions

**Module:** Sessions  
**File path(s):**
- `artifacts/api-server/src/routes/session.ts`
- `lib/db/src/schema/sessions.ts`
- `artifacts/nclex-prep/src/hooks/useSessionId.ts`
- `artifacts/nclex-prep/src/lib/session.ts`

**Purpose:** Anonymous + authenticated session management; tracks questions answered, subscription status, email, and Stripe customer/subscription IDs.

**Called by:**
- `routes/session.ts` — direct session CRUD
- `routes/adaptive.ts` — reads answers by sessionId
- `routes/stripe.ts` — reads/writes stripeCustomerId, referralCode
- `webhookHandlers.ts` — writes isSubscribed, stripeCustomerId, stripeSubscriptionId

**Calls:** PostgreSQL `sessions` and `answers` tables via Drizzle ORM  
**API routes:**
| Route | Method | Description |
|---|---|---|
| `/api/session/status` | GET | Get session stats + subscription state |
| `/api/session/answer` | POST | Submit answer; enforces free limit (10) |
| `/api/subscription/checkout` | POST | Legacy stub — returns `checkoutUrl: null` |
| `/api/subscription/cancel` | POST | Soft-cancel (sets `isSubscribed: false`, clears `subscriptionEndDate`) |

**Database tables:** `sessions` (read/write), `answers` (write on submit)  
**Authentication method:** `sessionId` query param or request body (string; no signature, no JWT)  
**Authorization method:** Free limit enforced: `questionsAnswered >= 10 AND !isSubscribed` → HTTP 403  
**Stripe interaction:** Reads `stripeCustomerId`/`stripeSubscriptionId` from `sessions`; does not call Stripe SDK directly  
**Clerk interaction:** None server-side. Frontend resolves `sessionId` via `useSessionId()`: returns `user.id` from Clerk if signed in, else a UUID from `localStorage`  
**Tests:** None  
**Known limitations:**
- `sessionId` is a client-controlled string with no signature — any client can supply any sessionId, including another user's, and read their subscription state or submit answers on their behalf
- `questionsAnswered` is incremented by +1 on each answer submission; it is NOT recounted from the `answers` table — out of sync if answers are inserted by any other path
- `subscription/checkout` route (POST) is a dead stub returning `checkoutUrl: null`; the real checkout is at `/api/stripe/checkout`
- `subscription/cancel` only updates the DB row — does NOT cancel the Stripe subscription object; user can be re-subscribed by the next `invoice.payment_succeeded` webhook

**TODO/FIXME items:** None found in source

---

## 6. Subscription System

**Module:** Subscription System  
**File path(s):**
- `artifacts/api-server/src/routes/stripe.ts` (checkout creation)
- `artifacts/api-server/src/webhookHandlers.ts` (webhook-driven activation)
- `artifacts/nclex-prep/src/pages/paywall.tsx`
- `artifacts/nclex-prep/src/pages/subscribe-success.tsx`

**Purpose:** Two-plan subscription (monthly recurring / lifetime one-time); Stripe Checkout-hosted flow; webhook-driven access grant.

**Called by:** Paywall page; subscribe-success page; Stripe webhook delivery  
**Calls:** Stripe SDK, Drizzle ORM  
**API routes:**
| Route | Method | Auth | Description |
|---|---|---|---|
| `/api/stripe/checkout` | POST | None | Create Stripe Checkout Session |
| `/api/stripe/verify-checkout` | POST | None | Verify payment (polled from success page) |
| `/api/stripe/webhook` | POST | stripe-signature | Activate subscription, pay affiliates |

**Database tables written:** `sessions.isSubscribed`, `sessions.stripeCustomerId`, `sessions.stripeSubscriptionId`, `sessions.referralCode`  
**Authentication method:** None — `sessionId` from request body  
**Authorization method:** None — any `sessionId` can initiate checkout; Stripe controls actual payment  
**Stripe interaction:** Full checkout, customer create, product/price lookup, webhook processing  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- Products resolved by name string match (`name:'NCLEX AI Monthly'`) — renaming product in Stripe dashboard breaks checkout
- Price selection takes the first active price for the product — no way to specify a price ID from the frontend
- Webhook `checkout.session.completed` activates the session using `metadata.sessionId`; if checkout is completed on a different device/browser, the original `sessionId` is still activated (correct, but can confuse users who switch devices)
- No expiry enforcement for subscriptions: `subscriptionEndDate` column exists but is never set by any code path; Stripe's `customer.subscription.deleted` event is the only revocation mechanism

**TODO/FIXME items:** None found

---

## 7. Restore Access

**Module:** Restore Access  
**File path(s):**
- `artifacts/api-server/src/routes/stripe.ts` (lines 168–225)
- `artifacts/nclex-prep/src/hooks/useAutoRestore.ts`
- `artifacts/nclex-prep/src/pages/paywall.tsx`

**Purpose:** Restores subscription access by email lookup against Stripe completed checkout sessions and customer records.

**Called by:** `useAutoRestore` hook (fires on paywall mount); manual restore form on paywall page  
**Calls:** `stripe.checkout.sessions.search`, `stripe.customers.list`, `stripe.checkout.sessions.list`  
**API routes:**
| Route | Method | Auth | Description |
|---|---|---|---|
| `/api/stripe/restore-access` | POST | None | Find Stripe customer by email, activate session |

**Database tables written:** `sessions` — upserts `isSubscribed`, `stripeCustomerId`, `stripeSubscriptionId`  
**Authentication method:** None — email provided by user (self-reported, not verified)  
**Authorization method:** Relies on Stripe's customer/payment records; if no completed checkout found for the email, access is denied  
**Stripe interaction:** `checkout.sessions.search` (with silent catch), then `customers.list` + `checkout.sessions.list` fallback  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- Email is not verified — any user who knows another user's Stripe checkout email can restore access to their own session
- `stripe.checkout.sessions.search` is caught silently (`catch (_) {}`) — search failures are invisible
- `useAutoRestore` fires on every paywall mount; if a user's stored email is valid, it silently re-activates their session without any confirmation step
- `useEagerRestore` (from same file) fires immediately on any page load if `getPaymentEmail()` returns a value — can generate many restore-access calls per session

**TODO/FIXME items:** None found

---

## 8. Adaptive Engine

**Module:** Adaptive Engine  
**File path(s):** `artifacts/api-server/src/routes/adaptive.ts`  
**Purpose:** Selects the next unanswered question using weighted-random category selection based on historical accuracy; weaker categories appear more often.

**Called by:** Frontend quiz page (`GET /api/adaptive/next`), performance display (`GET /api/adaptive/performance`)  
**Calls:** `answersTable`, `questionsTable` via Drizzle ORM  
**API routes:**
| Route | Method | Auth | Description |
|---|---|---|---|
| `/api/adaptive/next` | GET | None | Returns next question ID + category performance |
| `/api/adaptive/performance` | GET | None | Returns category accuracy stats |

**Database tables:** `answers` (read), `questions` (read)  
**Authentication method:** `sessionId` query param  
**Authorization method:** None — any sessionId can request adaptive next  
**Stripe interaction:** None  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- `computeAdaptiveNext()` is called by both `/adaptive/next` and `/adaptive/performance` — full DB computation runs twice per performance page load
- Orientation mode (first 2 questions = cardiac single-choice) hardcodes "cardiac" as a case-insensitive substring match on `category` — if category name changes in the DB, orientation silently falls back to random
- Weight formula `(1 - accuracy)^2 + 0.05` can produce near-zero weights for categories with 100% accuracy — those categories may never appear after mastery (only 0.05 probability mass)
- No seeding or determinism — each call uses `Math.random()` — same session can get different questions on repeated calls
- `notInArray(questionsTable.id, answeredIds)` with a large `answeredIds` array (1000+ entries) generates a very long SQL IN clause; potential performance issue for highly active sessions
- `/adaptive/performance` re-runs the full adaptive computation just to extract `categoryPerformance` — wasteful; a dedicated read-only query would be faster

**TODO/FIXME items:** None found

---

## 9. Question Bank

**Module:** Question Bank  
**File path(s):**
- `artifacts/api-server/src/routes/questions.ts`
- `lib/db/src/schema/questions.ts` (inferred from ORM usage)

**Purpose:** Read-only access to the question bank; list summaries and full question detail. Options normalization for legacy dict format.

**Called by:** Frontend quiz pages, admin seeding  
**Calls:** `questionsTable` via Drizzle ORM  
**API routes:**
| Route | Method | Auth | Description |
|---|---|---|---|
| `/api/questions` | GET | None | List all questions (id, questionNumber, category); optional `?category=` filter |
| `/api/questions/:id` | GET | None | Full question detail with options normalization |
| `/api/admin/seed-questions` | POST | Admin token | Bulk insert questions |

**Database tables:** `questions` (read; write via admin/seed-questions)  
**Authentication method:** None (public read)  
**Authorization method:** Seed endpoint requires `X-Admin-Secret`  
**Stripe interaction:** None  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- `/api/questions` returns ALL 1,508 questions in a single response — no pagination; will grow unbounded and eventually cause memory/timeout issues
- Options are returned in DB insertion order for old dict format (`Object.entries`) — key order in JS objects is not guaranteed by spec for non-numeric string keys; works in practice (V8) but is technically undefined behavior
- No validation that `selectedLetter` in `/session/answer` is one of the available option letters — any string is accepted
- `imageUrl` field exists but no images are served; the column is always null in production

**TODO/FIXME items:** None found

---

## 10. Affiliate System

**Module:** Affiliate System  
**File path(s):**
- `artifacts/api-server/src/routes/affiliates.ts`
- `artifacts/api-server/src/webhookHandlers.ts` (`sendAffiliateTransfer`)
- `lib/db/src/schema/affiliates.ts`
- `artifacts/nclex-prep/src/pages/admin-affiliates.tsx`

**Purpose:** Affiliate partner management with Stripe Connect Express; automatic commission transfers on lifetime purchases and monthly subscription renewals.

**Called by:** Admin UI frontend; webhook processor  
**Calls:** `affiliatesTable`, `sessionsTable` (referral count) via Drizzle ORM; Stripe Accounts, AccountLinks, Transfers APIs  
**API routes:**
| Route | Method | Auth | Description |
|---|---|---|---|
| `/api/admin/affiliates` | POST | Admin token | Create affiliate + Stripe Express account + onboarding link |
| `/api/admin/affiliates` | GET | Admin token | List affiliates with Stripe account status |
| `/api/admin/affiliates/:code/refresh-link` | POST | Admin token | Generate new Stripe onboarding link |
| `/api/admin/affiliates/:code` | DELETE | Admin token | Delete affiliate record |

**Database tables:** `affiliates` (read/write), `sessions` (read — referral count query)  
**Authentication method:** `X-Admin-Secret` header  
**Authorization method:** `requireAdmin()` helper — compares header to `process.env.ADMIN_TOKEN`  
**Stripe interaction:** `stripe.accounts.create`, `stripe.accountLinks.create`, `stripe.accounts.retrieve`, `stripe.transfers.create`  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- Deleting an affiliate with `DELETE /api/admin/affiliates/:code` does NOT cancel or close the Stripe Connect account — orphaned Connect account remains on Stripe
- No idempotency on `stripe.transfers.create` — a duplicate webhook delivery could double-pay commission
- `commissionPct` stored as integer; fractional percentages (e.g. 33.3%) are not representable
- Referral code is set on the session at checkout time and stored permanently; if an affiliate is deleted after a purchase, their `referralCode` on the session is still intact and future `invoice.payment_succeeded` lookups will fail silently (affiliate not found → transfer skipped)
- GET `/api/admin/affiliates` calls `stripe.accounts.retrieve` in parallel for every affiliate — N Stripe API calls per page load; no caching

**TODO/FIXME items:** None found

---

## 11. Admin System

**Module:** Admin  
**File path(s):**
- `artifacts/api-server/src/routes/stripe.ts` (seed-questions, fix-sessions, activate-sessions)
- `artifacts/api-server/src/routes/affiliates.ts` (affiliate CRUD)
- `artifacts/nclex-prep/src/pages/admin-affiliates.tsx`

**Purpose:** Administrative control over question seeding, session activation, session correction, and affiliate management.

**Called by:** Admin browser UI; direct API calls (curl, Postman)  
**Calls:** Drizzle ORM (questions, sessions, affiliates); Stripe API  
**API routes:**
| Route | Method | Auth | Description |
|---|---|---|---|
| `/api/admin/seed-questions` | POST | Admin token | Bulk question insert (50/batch, `onConflictDoNothing`) |
| `/api/admin/fix-sessions` | POST | Admin token | Nullify `isSubscribed` on sessions with no `stripeCustomerId` |
| `/api/admin/activate-sessions` | POST | Admin token | Force-activate a single session |
| `/api/admin/affiliates` | GET/POST | Admin token | Affiliate list and create |
| `/api/admin/affiliates/:code/refresh-link` | POST | Admin token | Regenerate onboarding link |
| `/api/admin/affiliates/:code` | DELETE | Admin token | Delete affiliate |

**Authentication method:** `X-Admin-Secret` header on every request  
**Authorization method:** String equality check against `process.env.ADMIN_TOKEN`  
**Known limitations:**
- No rate limiting — brute-force of the admin token is possible
- No expiry on the admin token — token must be manually rotated via Replit Secrets
- No audit log of admin actions — no record of who activated/fixed/deleted what and when
- `admin/fix-sessions` is a destructive bulk operation with no dry-run mode

**TODO/FIXME items:** None found

---

## 12. Database

**Module:** Database  
**File path(s):**
- `lib/db/src/index.ts`
- `lib/db/src/schema/questions.ts`
- `lib/db/src/schema/sessions.ts`
- `lib/db/src/schema/affiliates.ts`
- `lib/db/drizzle.config.ts`

**Purpose:** PostgreSQL connection pool, Drizzle ORM instance, typed table schemas and Zod insert validators.

**Called by:** All API server routes  
**Calls:** PostgreSQL via `pg` connection pool  
**Database tables:** `questions`, `sessions`, `answers`, `affiliates`  
**Authentication method:** N/A (server-side only)  
**Authorization method:** N/A  
**Stripe interaction:** Schema includes `stripeCustomerId`, `stripeSubscriptionId`, `stripeConnectId` columns  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- `drizzle.config.ts` has `tablesFilter: ["sessions","affiliates"]` — Drizzle Kit schema push/pull only manages `sessions` and `affiliates`; `questions` and `answers` are excluded from push and must be migrated manually or via raw SQL
- This filter also causes all TypeScript errors in `@workspace/api-server` typecheck (`Module '"@workspace/db"' has no exported member 'questionsTable'`) because tsc uses the Drizzle Kit config scope rather than the runtime schema exports — esbuild compiles fine at runtime
- No database-level foreign key constraints between tables (e.g. `answers.sessionId` → `sessions.sessionId`, `answers.questionId` → `questions.id`)
- No composite indexes on `answers(sessionId, questionId)` — full table scan on large sessions
- `sm_subscribers` table is written via raw SQL in `webhookHandlers.ts` — no Drizzle schema, no type safety, no migration management

**TODO/FIXME items:** None found

---

## 13. API Client Library

**Module:** API Client Library  
**File path(s):**
- `lib/api-client-react/src/`
- `lib/api-zod/src/`
- `lib/api-spec/openapi.yaml`
- `lib/api-spec/orval.config.ts`

**Purpose:** Auto-generated React Query hooks and Zod validators from OpenAPI 3.1 spec; enables type-safe API calls from the frontend.

**Called by:** Frontend pages (some — not all routes use the generated client; several pages use `fetch()` directly)  
**Calls:** `/api/*` endpoints via fetch  
**Database tables:** None  
**Authentication method:** N/A (HTTP client library)  
**Authorization method:** N/A  
**Stripe interaction:** None  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- Generated Zod validators in `@workspace/api-zod` are NOT wired into the API server — server-side validation is absent
- Several frontend pages (`paywall.tsx`, `subscribe-success.tsx`, `hooks/useAutoRestore.ts`) use raw `fetch()` instead of the generated hooks — inconsistent usage pattern
- Codegen command (`pnpm --filter @workspace/api-spec run codegen`) must be run manually when the OpenAPI spec changes — no automated CI step
- Generated files must not be edited manually — no lint rule to enforce this

**TODO/FIXME items:** None found

---

## 14. Logging

**Module:** Logging  
**File path(s):**
- `artifacts/api-server/src/lib/logger.ts`
- `artifacts/api-server/src/app.ts` (pino-http middleware)

**Purpose:** Structured JSON logging (pino) with pretty-printing in development.

**Called by:** All backend modules  
**Calls:** `pino`, `pino-http`, `pino-pretty`  
**API routes:** N/A  
**Database tables:** None  
**Authentication method:** N/A  
**Authorization method:** N/A  
**Stripe interaction:** None  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- URL logged without query string (privacy-friendly but loses `sessionId` from query params)
- Session IDs and customer emails appear in `info`-level log messages (e.g. "Session unlocked after successful checkout") — visible in Replit log viewer to anyone with repl access
- No log rotation or export — logs are ephemeral in the Replit container
- No alerting or error aggregation (Sentry, Datadog, etc.)

**TODO/FIXME items:** None found

---

## 15. Monitoring

**Module:** Monitoring  
**File path(s):** `artifacts/api-server/src/app.ts` (healthz only)  
**Purpose:** Liveness probe only (`GET /api/healthz` → `{status:"ok"}`).

**Called by:** Replit promote-phase prober  
**Calls:** None  
**API routes:** `GET /api/healthz`  
**Database tables:** None  
**Authentication method:** None  
**Authorization method:** None  
**Stripe interaction:** None  
**Clerk interaction:** None  
**Tests:** None  
**Known limitations:**
- Health check does NOT verify DB connectivity — server can report healthy while DB is unreachable
- No readiness probe separate from liveness
- No metrics endpoint (Prometheus, StatsD, etc.)
- No uptime monitoring configured externally
- No distributed tracing (no request trace IDs beyond pino-http request IDs)

**TODO/FIXME items:** None found

---

## 16. Deployment

**Module:** Deployment  
**File path(s):**
- `artifacts/api-server/.replit-artifact/artifact.toml`
- `artifacts/nclex-prep/.replit-artifact/artifact.toml`
- `artifacts/api-server/build.mjs`
- `artifacts/nclex-prep/vite.config.ts`

**Purpose:** Replit Reserved VM deployment; esbuild (API) + Vite (SPA) build pipeline.

**Called by:** Replit platform (artifact.toml service definitions)  
**Calls:** Node.js (API), static CDN (SPA)  
**API routes:** N/A  
**Database tables:** N/A  
**Authentication method:** N/A  
**Authorization method:** N/A  
**Stripe interaction:** `initStripe()` runs on startup — registers webhook, runs migrations, starts backfill  
**Clerk interaction:** `clerkMiddleware` initializes on first request  
**Tests:** None  
**Known limitations:**
- Must use Reserved VM (not Autoscale) — NCLEX has scheduled `initStripe()` on boot that must complete; autoscale cold-starts would re-run this on every instance
- No blue/green or canary deployment — all traffic shifts instantly to new version
- No rollback procedure documented
- Build outputs include source maps (6.6 MB `.map` file) — maps are shipped to production; may expose source to clients

**TODO/FIXME items:** None found

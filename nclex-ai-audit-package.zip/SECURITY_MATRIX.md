# NCLEX AI — Security Matrix

Generated: 2026-07-27  |  Git: 05a8808d10a8cbfe5cc206277dbb8bb7c72c5c9e

Legend:
- **Auth:** Does the endpoint verify caller identity?
- **Authz:** Does the endpoint enforce access control beyond identity?
- **Sub required:** Is `isSubscribed = true` enforced?
- **Admin required:** Is `X-Admin-Secret` enforced?
- **Validation:** Is the request body/query validated at runtime?
- **Rate limiting:** Is there a rate limit?
- **DB writes:** What tables are written?
- **Sensitive output:** Does the response contain sensitive data?
- **Tests:** Are there automated tests?
- **Verdict:** PASS = no material security gap | FAIL = material security gap

---

## Core / Infrastructure

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `GET /api/healthz` | None | None | No | No | None | No | None | No | No | **PASS** |

---

## Questions

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `GET /api/questions` | None | None | No | No | None (query param `category` unsanitized but Drizzle parameterizes) | No | None | No (summary only: id, questionNumber, category) | No | **PASS** |
| `GET /api/questions/:id` | None | None | No | No | `parseInt` + NaN check on `:id`; no body | No | None | Yes — returns `correctLetter` and `explanation` for **any** question regardless of subscription | No | **FAIL** — correct answer exposed to free/unauthenticated users |

**Detail on `/api/questions/:id`:** Any caller who knows a question ID (obtained from `/api/questions` list) can retrieve the correct answer and full explanation without a subscription. The paywall is enforced only on `/api/session/answer` (question count limit), not on reading question details. A free user can fetch all 1,508 answers without ever submitting through the quiz interface.

---

## Session

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `GET /api/session/status` | None | None | No | No | `sessionId` required (string presence check) | No | `sessions` (upsert on first call) | Yes — `isSubscribed`, `questionsAnswered`, `subscriptionEndDate` | No | **FAIL** — any caller who knows a `sessionId` can read another user's subscription state |
| `POST /api/session/answer` | None | None | Enforced (10-question limit) | No | Field presence check only; no type/format validation | No | `sessions` (questionsAnswered++), `answers` (insert) | Yes — `correctLetter`, `explanation` | No | **FAIL** — free limit check is a race condition (no DB transaction); `sessionId` is spoofable |
| `POST /api/subscription/checkout` | None | None | No | No | `sessionId` presence only | No | `sessions` (email update only) | No | No | **FAIL** — stub returns `checkoutUrl: null`; route is misleading and non-functional |
| `POST /api/subscription/cancel` | None | None | No | No | `sessionId` presence only | No | `sessions` (`isSubscribed = false`) | No | No | **FAIL** — does NOT cancel Stripe subscription; next invoice re-activates user |

---

## Adaptive Engine

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `GET /api/adaptive/next` | None | None | No | No | `sessionId` required | No | None | No (returns question ID only, no answer) | No | **PASS** |
| `GET /api/adaptive/performance` | None | None | No | No | `sessionId` required | No | None | Yes — per-category accuracy stats | No | **PASS** (low sensitivity) |

---

## Stripe / Payments

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `POST /api/stripe/checkout` | None | None | No | No | `sessionId` + `plan` presence; `plan` must be `"monthly"` or `"lifetime"` (implicit — falls to else branch) | No | `sessions` (customerId, referralCode) | Yes — returns Stripe checkout URL | No | **FAIL** — no rate limit; any caller can create unlimited Stripe customers |
| `POST /api/stripe/verify-checkout` | None | None | No | No | `sessionId` + `checkoutSessionId` presence | No | `sessions` (`isSubscribed`, `stripeCustomerId`, `stripeSubscriptionId`) | Yes — `email` from Stripe | No | **FAIL** — any caller who obtains a `checkoutSessionId` for another user can activate their own session |
| `POST /api/stripe/restore-access` | None | None | No | No | `sessionId` + `email` presence; email trimmed/lowercased | No | `sessions` (upsert `isSubscribed = true`) | No | No | **FAIL** — email self-reported; no verification; enables subscription theft |
| `POST /api/stripe/webhook` | `stripe-signature` header required | Event processed before cryptographic verification | N/A | No | Raw Buffer required (checked); event parsed from raw JSON unconditionally | No | `sessions` (`isSubscribed`, stripe IDs), `sm_subscribers` (raw SQL) | No | No | **FAIL** — webhook payload processed before `stripe.webhooks.constructEvent()` verification; forged events accepted |
| `POST /api/stripe/manage` (billing portal) | None | None | No | No | `sessionId` presence | No | None | Yes — Stripe billing portal URL | No | **FAIL** — any sessionId can trigger a billing portal session for any customer |
| `POST /api/stock-scanner/checkout` | None | None | No | No | `email` format check (`includes("@")`) | No | None (Stripe only) | Yes — checkout URL | No | **PASS** (StockScanner product, not NCLEX) |
| `POST /api/stock-scanner/manage` | None | None | No | No | `email` presence | No | None | Yes — billing portal URL | No | **PASS** |

**Detail on `/api/stripe/webhook`:**
```
// app.ts:23-40
app.post('/api/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const signature = req.headers['stripe-signature'];
  if (!signature) { res.status(400)...; return; }  // ← header presence only, NOT cryptographic
  await WebhookHandlers.processWebhook(req.body as Buffer, sig);
});

// webhookHandlers.ts:62-66
let event: any;
try {
  event = JSON.parse(payload.toString());  // ← parsed BEFORE stripe-replit-sync verification
} catch { return; }

try {
  const sync = await getStripeSync();
  await sync.processWebhook(payload, signature);  // ← may verify signature internally
} catch (err) { logger.warn(...) }  // ← failure is non-fatal; already parsed above
```
An attacker who can POST a crafted JSON body with any valid `stripe-signature` header (even a dummy string) will have their `event` object processed. The `stripe-replit-sync` call that might verify is wrapped in a `try/catch` that is non-fatal.

---

## Admin

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `POST /api/admin/seed-questions` | `X-Admin-Secret` header | String equality (no timing-safe) | No | Yes | Array presence; no Zod schema | No | `questions` (bulk insert) | No | No | **FAIL** — no rate limit (brute-force possible); no timing-safe comparison; no dry-run |
| `POST /api/admin/fix-sessions` | `X-Admin-Secret` header | String equality | No | Yes | None | No | `sessions` (bulk update `isSubscribed = false`) | No | No | **FAIL** — destructive bulk operation; no confirmation; no rate limit |
| `POST /api/admin/activate-sessions` | `X-Admin-Secret` header | String equality | No | Yes | `sessionId` presence | No | `sessions` (`isSubscribed = true`) | No | No | **FAIL** — no rate limit; no audit log |
| `GET /api/admin/affiliates` | `X-Admin-Secret` header | String equality | No | Yes | None | No | None | Yes — affiliate codes, Stripe Connect IDs, referral counts | No | **FAIL** — no rate limit; timing attack on admin token |
| `POST /api/admin/affiliates` | `X-Admin-Secret` header | String equality | No | Yes | `code` + `name` presence | No | `affiliates` (insert) | Yes — Stripe onboarding URL | No | **FAIL** — no rate limit |
| `POST /api/admin/affiliates/:code/refresh-link` | `X-Admin-Secret` header | String equality | No | Yes | Code from URL param | No | None | Yes — Stripe onboarding URL | No | **FAIL** — no rate limit |
| `DELETE /api/admin/affiliates/:code` | `X-Admin-Secret` header | String equality | No | Yes | Code from URL param | No | `affiliates` (delete) | No | No | **FAIL** — no audit log; leaves orphaned Stripe Connect account |

---

## AI Routes

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `POST /api/analyze` | None | None | No | No | None | No | None | No (AI-generated text) | No | **FAIL** — no auth, no rate limit; caller can burn Anthropic API quota indefinitely |
| `POST /api/catalyst` | None | None | No | No | None | No | None | No | No | **FAIL** — same as above |
| `GET /api/morning-brief` | None | None | No | No | None | No | None | No | No | **PASS** (cached; low abuse potential) |

---

## Clerk Proxy

| Route | Auth | Authz | Sub req | Admin req | Validation | Rate limit | DB writes | Sensitive output | Tests | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| `* /api/__clerk/*` | None (proxy) | None | No | No | None (transparent proxy) | No | None | Yes — passes Clerk auth tokens | No | **PASS** (Clerk validates downstream) |

---

## Summary

| Verdict | Count | Routes |
|---|---|---|
| PASS | 8 | healthz, questions (list), adaptive/next, adaptive/performance, stock-scanner/checkout, stock-scanner/manage, morning-brief, clerk proxy |
| FAIL | 16 | questions/:id, session/status, session/answer, subscription/checkout, subscription/cancel, stripe/checkout, stripe/verify-checkout, stripe/restore-access, stripe/webhook, stripe/manage, admin/seed-questions, admin/fix-sessions, admin/activate-sessions, admin/affiliates (all 3), analyze, catalyst |

**Top 5 issues by severity:**
1. **Webhook forgery** — `stripe/webhook` processes events before signature verification
2. **Subscription theft** — `restore-access` trusts self-reported email
3. **sessionId spoofing** — all session/subscription operations accept any string as identity
4. **Correct answers exposed** — `questions/:id` returns `correctLetter` + `explanation` to unauthenticated callers
5. **No rate limiting anywhere** — every endpoint is open to abuse/DoS

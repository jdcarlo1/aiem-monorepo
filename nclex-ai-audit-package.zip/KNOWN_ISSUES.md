# NCLEX AI — Known Issues

Generated: 2026-07-27  |  Git: 05a8808d10a8cbfe5cc206277dbb8bb7c72c5c9e

---

## CRITICAL

### C-01 — `sessionId` is client-controlled with no signature or secret
**File:** `artifacts/api-server/src/routes/session.ts:58-113`  
**Detail:** `sessionId` is a plain string sent as a query param or in the request body. Any caller who knows another user's session ID (a Clerk user ID or a localStorage UUID) can submit answers on their behalf, read their subscription status, and trigger checkout using their session. Clerk user IDs are not private (they appear in JWTs decoded by the browser). There is no session token, no HMAC, and no server-side binding of `sessionId` to an IP, device, or Clerk JWT.  
**Impact:** Account takeover of anonymous and authenticated sessions; free-limit bypass by creating answers against a subscribed session; subscription state manipulation.  
**Fix:** Bind `sessionId` to the authenticated Clerk user via `requireAuth()` for subscribed actions; or sign session IDs with a server secret; or validate that the `sessionId` in the request matches `req.auth.userId` when a Clerk JWT is present.

---

### C-02 — `restore-access` trusts user-supplied email without verification
**File:** `artifacts/api-server/src/routes/stripe.ts:168-225`  
**Detail:** POST `/api/stripe/restore-access` accepts `{sessionId, email}` and activates `sessions.isSubscribed = true` for the given `sessionId` if any Stripe customer with that email has a completed checkout. The email is not verified against any authentication mechanism — a user who knows another subscriber's email can steal their subscription to their own session.  
**Impact:** Subscription theft — any user can grant themselves access by entering any known subscriber's email.  
**Fix:** Require Clerk authentication for restore-access; validate that the email matches the Clerk user's verified email; or add an email-confirmation OTP step.

---

### C-03 — TypeScript errors suppress type safety across all DB table exports
**File:** `lib/db/drizzle.config.ts`  
**Detail:** `tablesFilter: ["sessions","affiliates"]` scopes Drizzle Kit to only those two tables. As a result, `tsc` cannot resolve `questionsTable`, `answersTable`, or `affiliatesTable` from `@workspace/db` — generating 14 of the 19 API server typecheck errors. esbuild bypasses `tsc` and compiles successfully, but the type errors mean that any future type-unsafe code change to the question/answer/affiliate paths will not be caught at compile time.  
**Impact:** Type safety lost for the core question-serving and affiliate payout code paths.  
**Fix:** Add `questions` and `answers` to `tablesFilter` in `drizzle.config.ts`; or restructure the DB package to export schemas independently of the Drizzle Kit config.

---

### C-04 — `subscription/cancel` does not cancel the Stripe subscription
**File:** `artifacts/api-server/src/routes/session.ts:139-164`  
**Detail:** POST `/api/subscription/cancel` sets `isSubscribed = false` and `subscriptionEndDate = null` in the local DB but does NOT call `stripe.subscriptions.cancel()`. The next `invoice.payment_succeeded` webhook (at the next billing cycle) will re-set `isSubscribed = true` automatically (since the webhook fires even after this route). The user believes they cancelled but continues to be charged and re-activated.  
**Impact:** Users cannot cancel subscriptions; continued charges; potential chargeback risk.  
**Fix:** Call `stripe.subscriptions.cancel(stripeSubscriptionId)` before updating the DB row; or redirect to the Stripe billing portal.

---

## HIGH

### H-01 — No rate limiting on any endpoint
**File:** `artifacts/api-server/src/app.ts`  
**Detail:** No rate limiting middleware (express-rate-limit, Nginx, etc.) is configured on any endpoint. All endpoints are callable at arbitrary frequency from any IP.  
**Impact:**
- Free limit bypass via rapid `/api/session/answer` calls (DB write race, see H-02)
- Brute-force of `ADMIN_TOKEN` via `/api/admin/*`
- Stripe API quota exhaustion via rapid calls to `/api/stripe/checkout` or `/api/stripe/restore-access`
- DoS by flooding any endpoint with large payloads

---

### H-02 — Free-limit check is a read-then-write race condition
**File:** `artifacts/api-server/src/routes/session.ts:70-112`  
**Detail:** The answer submission flow is:
1. Read `session.questionsAnswered` from DB
2. Check `questionsAnswered >= FREE_LIMIT`
3. Insert answer row
4. Update `questionsAnswered + 1`

Steps 1–4 are not atomic. Two concurrent requests can both read `questionsAnswered = 9`, both pass the check, and both write — resulting in 11+ questions answered past the limit. No database transaction or `SELECT FOR UPDATE` is used.  
**Impact:** Free limit bypass under concurrent load or deliberately concurrent API calls.  
**Fix:** Wrap in a DB transaction with `SELECT FOR UPDATE`; or use a DB-level trigger to count from the `answers` table.

---

### H-03 — No affiliate transfer idempotency
**File:** `artifacts/api-server/src/webhookHandlers.ts:42-48`  
**Detail:** `stripe.transfers.create()` is called with no `idempotencyKey`. Stripe delivers webhooks with at-least-once semantics; duplicate `checkout.session.completed` or `invoice.payment_succeeded` events will trigger duplicate `stripe.transfers.create` calls, doubling (or more) affiliate commission payouts.  
**Impact:** Monetary loss — affiliates paid multiple times per event.  
**Fix:** Pass `idempotencyKey: event.id` (or `event.id + affiliate.code`) to `stripe.transfers.create`.

---

### H-04 — `subscription/checkout` stub returns `checkoutUrl: null`
**File:** `artifacts/api-server/src/routes/session.ts:115-137`  
**Detail:** POST `/api/subscription/checkout` exists as a legacy route and returns `{"message": "Stripe integration coming soon.", "checkoutUrl": null}`. The real checkout is at `/api/stripe/checkout`. If any client calls the wrong route, they receive a success-looking 200 response with no URL and no payment is initiated. The route is in the OpenAPI spec and generated client.  
**Impact:** Silent payment failure — users think they subscribed but no charge occurs.  
**Fix:** Remove the stub or redirect to `/api/stripe/checkout`.

---

### H-05 — Source maps shipped to production
**File:** `artifacts/api-server/build.mjs`  
**Detail:** esbuild is configured with `sourcemap: true`, producing `dist/index.mjs.map` (6.6 MB). This file is shipped to the production container and is accessible if the server's filesystem can be read. Source maps allow full reconstruction of the original TypeScript source.  
**Impact:** Source code disclosure if the production VM is compromised.  
**Fix:** Disable source maps in production builds (`NODE_ENV === 'production'`); or store maps in a private artifact registry only.

---

### H-06 — No CORS restriction
**File:** `artifacts/api-server/src/app.ts:65`  
**Detail:** `cors({ credentials: true, origin: true })` — any origin can make credentialed cross-origin requests to the API.  
**Impact:** Cross-origin requests from any domain can call any API endpoint including admin routes (if admin token is leaked or guessable) and checkout endpoints.  
**Fix:** Restrict `origin` to `["https://nclexai.org", /\.replit\.dev$/]`.

---

### H-07 — No server-side request body validation
**File:** All route files  
**Detail:** Zod validators are generated in `@workspace/api-zod` but are not applied in any Express route handler. All `req.body` values are cast directly with `as { field: type }` — TypeScript type assertions, not runtime validation. Malformed, missing, or oversized bodies are not rejected.  
**Impact:** Unexpected `undefined`/`null` values propagate to DB queries; potential unhandled errors; oversized payloads could exhaust memory (though `express.json()` has a default 100 KB limit).  
**Fix:** Apply `@workspace/api-zod` validators as Express middleware on each route; or use a Zod parse step at the top of each handler.

---

### H-08 — `sm_subscribers` table accessed via raw SQL, no schema
**File:** `artifacts/api-server/src/webhookHandlers.ts:116-127`, `163-170`  
**Detail:** The `sm_subscribers` table (StockScanner subscribers) is written with raw `db.execute(sql\`...\`)` — no Drizzle schema, no TypeScript types, no migration file. If the table doesn't exist (e.g. new environment setup), the webhook handler throws a runtime exception on every checkout, which could suppress NCLEX session activation.  
**Impact:** Runtime crashes in webhook handler; NCLEX session activation may fail if `sm_subscribers` insert throws and is not caught.  
**Fix:** Add a `try/catch` around `sm_subscribers` operations; define a Drizzle schema; add to migration.

---

## MEDIUM

### M-01 — 19 TypeScript errors in API server
**Raw tsc output:**
```
src/index.ts(24,40): error TS2353: Object literal may only specify known properties, and 'schema' does not exist in type 'MigrationConfig'.
src/routes/adaptive.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'answersTable'.
src/routes/adaptive.ts(2,28): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/affiliates.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'affiliatesTable'.
src/routes/affiliates.ts(2,31): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/routes/catalyst.ts(10,26): error TS7030: Not all code paths return a value.
src/routes/morning-brief.ts(17,30): error TS7030: Not all code paths return a value.
src/routes/morning-brief.ts(32,29): error TS18046: 'flowData' is of type 'unknown'.
src/routes/questions.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/session.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/routes/session.ts(2,29): error TS2305: Module '"@workspace/db"' has no exported member 'answersTable'.
src/routes/session.ts(2,43): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/stripe.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/routes/stripe.ts(2,29): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/stripe.ts(2,45): error TS2305: Module '"@workspace/db"' has no exported member 'affiliatesTable'.
src/routes/stripe.ts(191,58): error TS2339: Property 'search' does not exist on type 'SessionResource'.
src/stripeClient.ts(39,24): error TS18046: 'data' is of type 'unknown'.
src/webhookHandlers.ts(1,14): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/webhookHandlers.ts(1,29): error TS2305: Module '"@workspace/db"' has no exported member 'affiliatesTable'.
```
**Root cause:** `tablesFilter` in `drizzle.config.ts` (see C-03) + `runMigrations` `schema` option not in SDK types.

---

### M-02 — 16 TypeScript errors in NCLEX frontend
**Raw tsc output:**
```
src/pages/admin-affiliates.tsx(154,19): error TS2322: Type '(token?: string) => Promise<void>' is not assignable to type 'MouseEventHandler<HTMLButtonElement>'.
src/pages/home.tsx(77,7): error TS2741: Property 'queryKey' is missing in type '{ enabled: boolean; }' but required in type 'UseQueryOptions<...>'.
src/pages/interview-prep.tsx(113,7): error TS2741: Property 'queryKey' is missing ...
src/pages/interview-prep.tsx(131,7): error TS2741: Property 'queryKey' is missing ...
src/pages/interview-prep.tsx(149,47): error TS18048: 'currentQuestion.correctLetter' is possibly 'undefined'.
src/pages/interview-prep.tsx(152,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/interview-prep.tsx(153,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/nursing-school.tsx(873,7): error TS2741: Property 'queryKey' is missing ...
src/pages/quiz.tsx(415,7): error TS2741: Property 'queryKey' is missing ...
src/pages/quiz.tsx(457,7): error TS2741: Property 'queryKey' is missing ...
src/pages/study-quiz.tsx(535,7): error TS2741: Property 'queryKey' is missing ...
src/pages/study-quiz.tsx(553,7): error TS2741: Property 'queryKey' is missing ...
src/pages/study-quiz.tsx(600,11): error TS18048: 'currentQuestion.correctLetter' is possibly 'undefined'.
src/pages/study-quiz.tsx(604,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/study-quiz.tsx(605,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/study-quiz.tsx(786,17): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
```
**Root cause:** `queryKey` required in React Query v5 `UseQueryOptions` but omitted; `correctLetter` typed as `string | undefined` but used as `string`.

---

### M-03 — `questionsAnswered` counter can diverge from actual `answers` table count
**File:** `artifacts/api-server/src/routes/session.ts:98-102`  
**Detail:** `questionsAnswered` is incremented by 1 on each answer POST. It is never validated or resynced against `COUNT(*) FROM answers WHERE session_id = ?`. Any external insert, bug, or admin action that writes to `answers` without incrementing `sessions.questionsAnswered` creates permanent drift.

---

### M-04 — GET `/api/questions` has no pagination
**File:** `artifacts/api-server/src/routes/questions.ts:7-23`  
**Detail:** Returns all 1,508+ questions in a single response with no `limit`/`offset` or cursor. Response will grow as the question bank grows.  
**Impact:** Latency and memory pressure as question bank scales; potential timeout on very large banks.

---

### M-05 — `useAutoRestore` fires silently on every paywall mount
**File:** `artifacts/nclex-prep/src/hooks/useAutoRestore.ts`  
**Detail:** On mount, reads `getPaymentEmail()` from localStorage and immediately POSTs to `/api/stripe/restore-access` without any user interaction. This generates Stripe API lookups on every paywall visit.  
**Impact:** Stripe rate limit risk; confusing UX if restore silently fails.

---

### M-06 — Admin token brute-force possible
**File:** `artifacts/api-server/src/routes/affiliates.ts:8-16`, `routes/stripe.ts:228-231`  
**Detail:** `requireAdmin()` is a plain string equality check with no rate limiting, lockout, or constant-time comparison. The admin token is likely a fixed string stored in Replit Secrets.  
**Impact:** Offline dictionary/brute-force attack if token is short or predictable.  
**Fix:** Use `crypto.timingSafeEqual`; add rate limiting on `/api/admin/*`.

---

### M-07 — Adaptive engine performance route runs full computation twice
**File:** `artifacts/api-server/src/routes/adaptive.ts:130-143`  
**Detail:** `GET /api/adaptive/performance` calls `computeAdaptiveNext(sessionId)` — which runs all DB queries including the unanswered question list — then discards the `questionId` result and returns only `categoryPerformance`. This is wasteful; the performance query only needs the `answers` and `questions` tables scanned for answered questions, not all unanswered ones.

---

### M-08 — Stripe product resolved by name string — fragile coupling
**File:** `artifacts/api-server/src/routes/stripe.ts:73-86`, `101-114`  
**Detail:** Products are found via `stripe.products.search({ query: "name:'NCLEX AI Monthly' AND active:'true'" })`. Renaming the product in the Stripe dashboard breaks checkout silently (500 response: "product not found").  
**Fix:** Store Stripe Price IDs as environment variables; resolve by ID, not by name.

---

### M-09 — `getUncachableStripeClient()` creates a new Stripe instance on every call
**File:** `artifacts/api-server/src/stripeClient.ts:62-65`  
**Detail:** Every route call that uses Stripe instantiates a new `Stripe` object, including a potential network call to the Replit connector. Under load, this generates N×(connector round-trips) per request.  
**Fix:** Cache the Stripe client instance (invalidate if credentials change).

---

### M-10 — No database-level foreign key constraints
**File:** `lib/db/src/schema/sessions.ts`, `lib/db/src/schema/questions.ts`  
**Detail:** `answers.questionId` has no FK → `questions.id`; `answers.sessionId` has no FK → `sessions.session_id`; `sessions.referralCode` has no FK → `affiliates.code`. Orphaned rows are possible.

---

### M-11 — `sm_subscribers` has no Drizzle schema or migration
**File:** `artifacts/api-server/src/webhookHandlers.ts`  
**Detail:** The StockScanner subscriber table is accessed via raw SQL. There is no schema definition, no migration, and no ensure-exists guard. New environment setups will fail webhook processing with a table-not-found error.

---

### M-12 — No Stripe webhook signature cryptographic verification
**File:** `artifacts/api-server/src/webhookHandlers.ts:63-65`  
**Detail:** `stripe-replit-sync`'s `processWebhook` is called and may verify the signature internally, but the raw event is also parsed unconditionally from `JSON.parse(payload.toString())` before the sync call — meaning even if the sync call fails, the event is still processed. An attacker who can POST to `/api/stripe/webhook` with a forged JSON body (no valid `stripe-signature`) will have their payload processed.  
**Severity note:** The `stripe-signature` header is checked for presence at `app.ts:28-31`, but is NOT cryptographically verified by the custom `WebhookHandlers.processWebhook` before processing.  
**Fix:** Call `stripe.webhooks.constructEvent(payload, signature, webhookSecret)` before processing; reject any event that fails verification.

---

## LOW

### L-01 — `subscription/cancel` route is misleading
**File:** `artifacts/api-server/src/routes/session.ts:139-164`  
**Detail:** Route name implies Stripe subscription cancellation but only updates DB. No Stripe API call is made. See C-04 for full impact.

### L-02 — Cookie/email based `getPaymentEmail()` is stored in localStorage
**File:** `artifacts/nclex-prep/src/lib/session.ts`  
**Detail:** Payment email is persisted in localStorage (`payment_email`). localStorage is accessible to any script on the same origin — XSS vulnerability could exfiltrate it.

### L-03 — `updatedAt` column on `sessions` relies on Drizzle `$onUpdate` — not DB trigger
**File:** `lib/db/src/schema/sessions.ts:16`  
**Detail:** `updatedAt.$onUpdate(() => new Date())` only fires when Drizzle's `update()` is used. Raw SQL updates (as used for `sm_subscribers`) bypass this. If sessions are ever updated via raw SQL, `updatedAt` will not be set.

### L-04 — No pagination on GET `/api/admin/affiliates`
**File:** `artifacts/api-server/src/routes/affiliates.ts:115-152`  
**Detail:** Returns all affiliates; calls Stripe Connect `accounts.retrieve` for each one serially in a `Promise.all`. With many affiliates, this is N Stripe API calls per page load.

### L-05 — `crypto.randomUUID().replace(/-/g, '')` token for StockScanner
**File:** `artifacts/api-server/src/webhookHandlers.ts:115`  
**Detail:** Access token for `sm_subscribers` is a UUID v4 stripped of dashes. UUIDs are cryptographically random but 122 bits, not 256 bits. Acceptable for most use cases; note for auditors.

### L-06 — No Content Security Policy header
**File:** `artifacts/nclex-prep/index.html`  
**Detail:** No CSP header is set. Scripts, styles, and connections are unrestricted.

### L-07 — Deleting an affiliate leaves orphaned Stripe Connect account
**File:** `artifacts/api-server/src/routes/affiliates.ts:154-160`  
**Detail:** `DELETE /api/admin/affiliates/:code` removes the DB row but does not close or deactivate the Stripe Connect Express account (`stripe.accounts.delete` or `stripe.accounts.reject` is not called).

### L-08 — No audit log for admin actions
**File:** All admin routes  
**Detail:** No record is kept of which admin actions were performed, by whom, and when. If the admin token is shared, there is no accountability.

### L-09 — Large `notInArray` SQL clause on high-usage sessions
**File:** `artifacts/api-server/src/routes/adaptive.ts:49-56`  
**Detail:** `notInArray(questionsTable.id, answeredIds)` generates `WHERE id NOT IN (1, 2, 3, ...)` with all answered question IDs. For a session that has answered hundreds of questions, this becomes a very long SQL literal. PostgreSQL handles this well but it is inefficient vs. a LEFT JOIN anti-join or EXISTS clause.

### L-10 — `/api/admin/seed-questions` accepts any question structure without validation
**File:** `artifacts/api-server/src/routes/stripe.ts:227-262`  
**Detail:** `req.body.questions` is cast directly without Zod validation. Fields like `questionNumber`, `category`, `text`, `options`, `correctLetter`, `explanation`, and `questionType` are all user-supplied with no type/format enforcement.

### L-11 — No automated test suite exists
**File:** Entire project  
**Detail:** No Vitest, Jest, or Playwright configuration. No unit, integration, or end-to-end tests. All verification is manual.

### L-12 — No dependency audit has been run
**File:** `package.json` (all packages)  
**Detail:** `pnpm audit` is not in CI. No automated vulnerability scanning. See TEST_STATUS.md for audit output.

### L-13 — OpenAPI spec may be out of sync with implementation
**File:** `lib/api-spec/openapi.yaml`  
**Detail:** Several routes in the implementation (`/api/stripe/verify-checkout`, `/api/stock-scanner/checkout`, `/api/admin/seed-questions`, `/api/admin/fix-sessions`) may not be reflected in the spec; codegen runs manually and is not validated in CI.

### L-14 — `pino-http` URL serializer strips query strings
**File:** `artifacts/api-server/src/app.ts:52`  
**Detail:** `url: req.url?.split("?")[0]` strips all query parameters from request logs. `sessionId` passed as `?sessionId=` is invisible in logs, making debugging session-specific issues harder.

### L-15 — `subscriptionEndDate` column is never populated
**File:** `lib/db/src/schema/sessions.ts:10`  
**Detail:** `subscriptionEndDate` exists in the DB schema but no code path ever sets it to a non-null value. Subscription expiry is controlled entirely by the `customer.subscription.deleted` webhook. If the webhook is missed or delayed, sessions remain active indefinitely.

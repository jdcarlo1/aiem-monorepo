# NCLEX AI — Test Status

Generated: 2026-07-27  |  Git: 05a8808d10a8cbfe5cc206277dbb8bb7c72c5c9e

---

## Build Status

### API Server (`artifacts/api-server`)

```
$ pnpm --filter @workspace/api-server run build

> @workspace/api-server@0.0.0 build
> node build.mjs

  dist/index.mjs                       4.1mb ⚠️
  dist/pino-worker.mjs               153.4kb
  dist/pino-file.mjs                 142.1kb
  dist/pino-pretty.mjs               114.6kb
  dist/thread-stream-worker.mjs        7.3kb
  dist/index.mjs.map                   6.6mb
  dist/pino-worker.mjs.map           256.9kb
  dist/pino-file.mjs.map             229.0kb
  dist/pino-pretty.mjs.map           204.0kb
  dist/thread-stream-worker.mjs.map   12.0kb

⚡ Done in 545ms
```

**Result: ✅ PASS** — esbuild produces a complete runnable bundle; does not run tsc.

---

### Frontend (`artifacts/nclex-prep`)

```
$ pnpm --filter @workspace/nclex-prep run build

> @workspace/nclex-prep@0.0.0 build
> vite build

src/components/ui/tooltip.tsx (2:0): Error when using sourcemap for reporting an error:
  Can't resolve original location of error.
src/components/ui/progress.tsx (2:0): Error when using sourcemap for reporting an error:
  Can't resolve original location of error.

(!) Some chunks are larger than 500 kB after minification. Consider:
- Using dynamic import() to code-split the application
- Use build.rollupOptions.output.manualChunks to improve chunking

dist/public/assets/index-[hash].js   647 KB (gzip: ~185 KB)
dist/public/assets/index-[hash].css  138 KB (gzip: ~22 KB)

Done in 3.89s
```

**Result: ✅ PASS** — Vite builds successfully; the sourcemap warnings are cosmetic (Radix UI components); chunk size warning is advisory only.

---

## Typecheck Status

### API Server

```
$ pnpm --filter @workspace/api-server run typecheck

> @workspace/api-server@0.0.0 typecheck
> tsc -p tsconfig.json --noEmit

src/index.ts(24,40): error TS2353: Object literal may only specify known properties,
  and 'schema' does not exist in type 'MigrationConfig'.
src/routes/adaptive.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'answersTable'.
src/routes/adaptive.ts(2,28): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/affiliates.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'affiliatesTable'.
src/routes/affiliates.ts(2,31): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/routes/catalyst.ts(10,26): error TS7030: Not all code paths return a value.
src/routes/morning-brief.ts(17,30): error TS7030: Not all code paths return a value.
src/routes/morning-brief.ts(32,29): error TS18046: 'flowData' is of type 'unknown'.
src/routes/questions.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/session.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/routes/session.ts(2,29): error TS2305: Module '"@workspace/db"' has no exported member 'answersTable'.
src/routes/session.ts(2,43): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/stripe.ts(2,14): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/routes/stripe.ts(2,29): error TS2305: Module '"@workspace/db"' has no exported member 'questionsTable'.
src/routes/stripe.ts(2,45): error TS2305: Module '"@workspace/db"' has no exported member 'affiliatesTable'.
src/routes/stripe.ts(191,58): error TS2339: Property 'search' does not exist on type 'SessionResource'.
src/stripeClient.ts(39,24): error TS18046: 'data' is of type 'unknown'.
src/webhookHandlers.ts(1,14): error TS2305: Module '"@workspace/db"' has no exported member 'sessionsTable'.
src/webhookHandlers.ts(1,29): error TS2305: Module '"@workspace/db"' has no exported member 'affiliatesTable'.

Exit status 2
```

**Result: ❌ FAIL — 19 errors across 10 files**

Root causes:
1. `tablesFilter: ["sessions","affiliates"]` in `lib/db/drizzle.config.ts` — 14 errors
2. `runMigrations({ schema: ... })` — `schema` not in SDK types — 1 error
3. `stripe.checkout.sessions.search` not typed at pinned API version — 1 error
4. `data` typed as `unknown` in `stripeClient.ts` — 1 error
5. Missing return paths in route handlers — 2 errors

---

### Frontend

```
$ pnpm --filter @workspace/nclex-prep run typecheck

> @workspace/nclex-prep@0.0.0 typecheck
> tsc -p tsconfig.json --noEmit

src/pages/admin-affiliates.tsx(154,19): error TS2322: Type '(token?: string) => Promise<void>'
  is not assignable to type 'MouseEventHandler<HTMLButtonElement>'.
src/pages/home.tsx(77,7): error TS2741: Property 'queryKey' is missing in type
  '{ enabled: boolean; }' but required in type 'UseQueryOptions<SessionStatus, ...>'.
src/pages/interview-prep.tsx(113,7): error TS2741: Property 'queryKey' is missing ...
src/pages/interview-prep.tsx(131,7): error TS2741: Property 'queryKey' is missing ...
src/pages/interview-prep.tsx(149,47): error TS18048: 'currentQuestion.correctLetter' is possibly 'undefined'.
src/pages/interview-prep.tsx(152,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/interview-prep.tsx(153,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/nursing-school.tsx(873,7): error TS2741: Property 'queryKey' is missing ...
src/pages/quiz.tsx(415,7): error TS2741: Property 'queryKey' is missing ...
src/pages/quiz.tsx(457,7): error TS2741: Property 'queryKey' is missing ...
src/pages/study-quiz.tsx(535,7): error TS2741: Property 'queryKey' is missing ...
src/pages/study-quiz.tsx(553,7): error TS2741: Property 'queryKey' is missing ...
src/pages/study-quiz.tsx(600,11): error TS18048: 'currentQuestion.correctLetter' is possibly 'undefined'.
src/pages/study-quiz.tsx(604,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/study-quiz.tsx(605,7): error TS2322: Type 'string | undefined' is not assignable to type 'string'.
src/pages/study-quiz.tsx(786,17): error TS2322: Type 'string | undefined' is not assignable to type 'string'.

Exit status 2
```

**Result: ❌ FAIL — 16 errors across 6 files**

Root causes:
1. `queryKey` required in React Query v5 `UseQueryOptions` but not passed in `useQuery({enabled: ...})` — 7 errors across 5 files
2. `correctLetter` typed as `string | undefined` by Drizzle/Zod inference but used as `string` — 5 errors across 2 files
3. `onClick` handler signature mismatch in admin-affiliates — 1 error
4. `string | undefined` assigned to `string` in study-quiz — 1 error

---

## Test Status

**No automated test suite exists for the NCLEX AI project.**

```
$ find artifacts/nclex-prep artifacts/api-server lib -name "*.test.*" -o -name "*.spec.*" | grep -v node_modules
(no output)

$ find artifacts/nclex-prep artifacts/api-server -name "vitest.config.*" -o -name "jest.config.*" -o -name "playwright.config.*" | grep -v node_modules
(no output)
```

| Test type | Status |
|---|---|
| Unit tests (Vitest/Jest) | ❌ None |
| Integration tests | ❌ None |
| End-to-end tests (Playwright) | ❌ None |
| API contract tests | ❌ None |
| Stripe webhook tests | ❌ None |
| Adaptive engine tests | ❌ None |

---

## Coverage

**Not applicable** — no test suite exists. Coverage is 0%.

---

## Security Scans

### Dependency Audit

```
$ pnpm audit
(pnpm audit does not support --recursive/--filter; run in each package)
```

**Audit not completed** — `pnpm audit` in this workspace does not support per-filter execution. A manual npm audit was not run. Recommended action: run `npm audit` in each of:
- `artifacts/api-server/`
- `artifacts/nclex-prep/`
- `lib/db/`
- `lib/api-client-react/`

Key dependency versions to watch:
| Package | Version in use | Notes |
|---|---|---|
| `stripe` | latest | Pinned to API version `2025-08-27.basil` |
| `@clerk/express` | latest | Auth library — keep current |
| `express` | v5.x | RC; not yet stable |
| `drizzle-orm` | latest | ORM |
| `@anthropic-ai/sdk` | latest | AI routes |

### Static Analysis

No SAST tool (Semgrep, Snyk, CodeQL, etc.) has been configured or run.

---

## Known Failing Tests

None — no tests exist.

---

## Missing Tests (recommended)

| Priority | Test | Description |
|---|---|---|
| HIGH | Stripe webhook signature verification | Verify that forged webhook payloads are rejected |
| HIGH | Free limit enforcement | Verify that exactly 10 free questions are allowed; 11th returns 403 |
| HIGH | Subscription activation | Verify `checkout.session.completed` sets `isSubscribed = true` |
| HIGH | Subscription cancellation | Verify `customer.subscription.deleted` sets `isSubscribed = false` |
| HIGH | Admin token auth | Verify that missing/wrong token returns 401 |
| HIGH | Concurrent answer submission race | Verify free limit is not bypassable with concurrent requests |
| MEDIUM | Adaptive engine category weighting | Unit test `computeAdaptiveNext` weight distribution |
| MEDIUM | Answer checking — multiple choice | Verify CSV comparison with different orderings |
| MEDIUM | Answer checking — ordered | Verify ordered sequence comparison |
| MEDIUM | Restore access — no email match | Verify 200 with `success: false` when email not found |
| MEDIUM | Restore access — valid email | Verify session is activated when email matches Stripe record |
| MEDIUM | Affiliate transfer idempotency | Verify duplicate webhook does not double-pay |
| LOW | Options normalization | Verify `{A: "text"}` dict is converted to `[{letter, text}]` array |
| LOW | Question not found | Verify 404 on invalid question ID |
| LOW | Health check | Verify `/api/healthz` returns 200 |
